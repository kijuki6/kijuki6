<?php
	include "../assets/header.php";
	include "../assets/body.php";
	include "../include/conn.php";
	include "includes/forgot_password.php";
	include "../assets/footer.php";
?>
<?php
	if(isset($_POST['update_bands']) || isset($_POST['submit_tax_update'])){
?>
	<h3>Update PAYE Tax Bands</h3>
	<div class="row gens">
		<div class="col-sm-12">
			<form action="" method="POST">
				<?php
					include '../include/conn.php';
					$search = "SELECT * FROM tax_paye WHERE org_id = ?";
					$searchStatement = mysqli_prepare($conn,$search);
					if(!$searchStatement){
						echo "";
					}else{
						mysqli_stmt_bind_param($searchStatement,'s',$username);
						mysqli_stmt_execute($searchStatement);
						$result = mysqli_stmt_get_result($searchStatement);
						$count = 0;
						$row = mysqli_fetch_assoc($result);
							
							@$tax_1 = $row['tax_band_name_1'];
							@$min_1 = $row['min_salary_1'];
							@$max_1 = $row['max_salary_1'];
							@$percentage_1 = $row['percentage_ded_1'];
							@$tax_2 = $row['tax_band_name_2'];
							@$min_2 = $row['min_salary_2'];
							@$max_2 = $row['max_salary_2'];
							@$percentage_2 = $row['percentage_ded_2'];
							@$tax_3 = $row['tax_band_name_3'];
							@$min_3 = $row['min_salary_3'];
							@$max_3 = $row['max_salary_3'];
							@$percentage_3 = $row['percentage_ded_3'];
							@$tax_4 = $row['tax_band_name_4'];
							@$min_4 = $row['min_salary_4'];
							@$percentage_4 = $row['percentage_ded_4'];
				?>
						<div class="row">
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="tax_band_name_1" value="<?php echo $tax_1;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="min_tax_1" value="<?php echo $min_1;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="max_tax_1" value="<?php echo $max_1;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="percentage_1" value="<?php echo $percentage_1;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="tax_band_name_2" value="<?php echo $tax_2;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="min_tax_2" value="<?php echo $min_2;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="max_tax_2" value="<?php echo $max_2;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="percentage_2" value="<?php echo $percentage_2;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="tax_band_name_3" value="<?php echo $tax_3;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="min_tax_3" value="<?php echo $min_3;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="max_tax_3" value="<?php echo $max_3;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="percentage_3" value="<?php echo $percentage_3;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="tax_band_name_4" value="<?php echo $tax_4;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="min_tax_4" value="<?php echo $min_4;?>">
							</div>
							<div class="col-sm-3 form-group">
								<!--<button class="form-control"></button>-->
								<!--<input type="text" class="form-control" name="max_tax_4" placeholder="Maximum Taxable Amount...">-->
							</div>
							<div class="col-sm-3 form-group">
								<input type="text" class="form-control" name="percentage_4" value="<?php echo $percentage_4;?>">
							</div>
							<div class="col-sm-3 form-group">
								<input type="submit" class="form-control approve" name="submit_tax_update" value="Submit">
							</div>
						</div>
				<?php
					}
				?>
			</form>
		</div>
	</div>
	<h3>Current PAYE Tax Bands</h3>
	<div class="row gens">
		<div class="col-sm-12">
			<table>
				<thead>
					<tr>
						<th>#</th>
						<th>Tax Band Name/Code</th>
						<th>Min</th>
						<th>Max</th>
						<th>Percentage</th>
					</tr>
				</thead>
				<tbody>
				<?php
					include '../include/conn.php';
					
					$read = "SELECT * FROM tax_paye WHERE org_id = ?";
					$readStatement = mysqli_prepare($conn,$read);
					if(!$readStatement){
						echo "";
					}else{
						mysqli_stmt_bind_param($readStatement,'s',$username);
						mysqli_stmt_execute($readStatement);
						$result = mysqli_stmt_get_result($readStatement);
						$count = 0;
						$row = mysqli_fetch_assoc($result);
							
							@$tax_1 = $row['tax_band_name_1'];
							@$min_1 = $row['min_salary_1'];
							@$max_1 = $row['max_salary_1'];
							@$percentage_1 = $row['percentage_ded_1'];
							@$tax_2 = $row['tax_band_name_2'];
							@$min_2 = $row['min_salary_2'];
							@$max_2 = $row['max_salary_2'];
							@$percentage_2 = $row['percentage_ded_2'];
							@$tax_3 = $row['tax_band_name_3'];
							@$min_3 = $row['min_salary_3'];
							@$max_3 = $row['max_salary_3'];
							@$percentage_3 = $row['percentage_ded_3'];
							@$tax_4 = $row['tax_band_name_4'];
							@$min_4 = $row['min_salary_4'];
							@$percentage_4 = $row['percentage_ded_4'];
				?>
					<tr>
						<td>1</td>
						<td><?php echo $tax_1;?></td>
						<td><?php echo $min_1;?></td>
						<td><?php echo $max_1;?></td>
						<td><?php echo $percentage_1;?></td>
					</tr>
					<tr>
						<td>2</td>
						<td><?php echo $tax_2;?></td>
						<td><?php echo $min_2;?></td>
						<td><?php echo $max_2;?></td>
						<td><?php echo $percentage_2;?></td>
					</tr>
					<tr>
						<td>3</td>
						<td><?php echo $tax_3;?></td>
						<td><?php echo $min_3;?></td>
						<td><?php echo $max_3;?></td>
						<td><?php echo $percentage_3;?></td>
					</tr>
					<tr>
						<td>4</td>
						<td><?php echo $tax_4;?></td>
						<td><?php echo $min_4;?></td>
						<td><?php echo $percentage_4;?></td>
					</tr>
				<?php
					}
				?>
				</tbody>
			</table>
		</div>
	</div>
<?php
	}
	if(isset($_POST['submit_tax_update'])){
		$tax_band_name_1 = $_POST['tax_band_name_1'];
		$min_tax_1 = $_POST['min_tax_1'];
		$max_tax_1 = $_POST['max_tax_1'];
		$percentage_tax_1 = $_POST['percentage_1'];
		$tax_band_name_2 = $_POST['tax_band_name_2'];
		$min_tax_2 = $_POST['min_tax_2'];
		$max_tax_2 = $_POST['max_tax_2'];
		$percentage_tax_2 = $_POST['percentage_2'];
		$tax_band_name_3 = $_POST['tax_band_name_3'];
		$min_tax_3 = $_POST['min_tax_3'];
		$max_tax_3 = $_POST['max_tax_3'];
		$percentage_tax_3 = $_POST['percentage_3'];
		$tax_band_name_4 = $_POST['tax_band_name_4'];
		$min_tax_4 = $_POST['min_tax_4'];
		$percentage_tax_4 = $_POST['percentage_4'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE tax_paye SET org_id =?, tax_band_name_1 =? ,min_salary_1 =?,max_salary_1 =?,percentage_ded_1 =?,tax_band_name_2 =?,min_salary_2 =?,max_salary_2 =?,percentage_ded_2 =?,tax_band_name_3 =?,min_salary_3 =?,max_salary_3 =?,percentage_ded_3 =?,tax_band_name_4 =?,min_salary_4 =?,percentage_ded_4 =?";
		$insertStatement = mysqli_prepare($conn,$sql);
		if(!$insertStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatement,'ssssssssssssssss',$username,$tax_band_name_1,$min_tax_1,$max_tax_1,$percentage_tax_1,$tax_band_name_2,$min_tax_2,$max_tax_2,$percentage_tax_2,$tax_band_name_3,$min_tax_3,$max_tax_3,$percentage_tax_3,$tax_band_name_4,$min_tax_4,$percentage_tax_4);
			mysqli_stmt_execute($insertStatement);
			echo "<h4 class='text-center'>Tax Band Successfully Updated</h4>";
			mysqli_close($conn);
		}
	}
?>
<?php
// Check if the form to add a new charge has been submitted
if (isset($_POST['charge_add']) || isset($_POST['charge_submit'])) {
    ?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Charge</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <select class="form-control" name="charge_name" required>
						<option value="">-- Select Charge --</option>
						<option value="LC">1. Late Coming</option>
					</select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="text" class="form-control" name="charge_code" placeholder="Charge Code...">
                </div>
                <div class="col-sm-3 form-group">
                    <input type="text" class="form-control" name="charge_amount" placeholder="Charge Amount...">
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="charge_submit" value="Add Charge">
                </div>
            </div>
        </form>
    </div>
    <?php
}

// Handle form submission to add a new charge
if (isset($_POST['charge_submit'])) {
    $charge_name = $_POST['charge_name'];
    $charge_code = $_POST['charge_code'];
    $charge_amount = $_POST['charge_amount'];
    
    include '../include/conn.php';
    
    $sql = "INSERT INTO org_charge(org_id, charge_name, charge_code, charge_amount) VALUES (?, ?, ?, ?)";
    $insertStatement = mysqli_prepare($conn, $sql);
    if ($insertStatement) {
        mysqli_stmt_bind_param($insertStatement, 'ssss', $username, $charge_name, $charge_code, $charge_amount);
        mysqli_stmt_execute($insertStatement);
        echo "<h4 class='text-center'>Charge Added Successfully!</h4>";
        mysqli_stmt_close($insertStatement);
    } else {
        echo "<h4 class='text-center'>Error Adding Charge!</h4>";
    }
    mysqli_close($conn);
}

// Check if the form to delete a charge has been submitted
if (isset($_POST['charge_del']) || isset($_POST['charge_delete_submit'])) {
    ?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Delete Charge</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <select class="form-control" name="charge">
                        <option value="">-- Select Charge to Delete --</option>
                        <?php
                        include '../include/conn.php';
                        $search = "SELECT * FROM org_charge WHERE org_id = ?";
                        $searchStatement = mysqli_prepare($conn, $search);
                        if ($searchStatement) {
                            mysqli_stmt_bind_param($searchStatement, 's', $username);
                            mysqli_stmt_execute($searchStatement);
                            $result = mysqli_stmt_get_result($searchStatement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $charge_name = $row['charge_name'];
                                $charge_code = $row['charge_code'];
                                $charge_amount = $row['charge_amount'];
                                ?>
                                <option value="<?php echo $charge_code; ?>"><?php echo $count . ". " . $charge_name . " " . $charge_code . " " . $charge_amount; ?></option>
                                <?php
                            }
                            mysqli_stmt_close($searchStatement);
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="charge_delete_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
    <?php
}

// Handle form submission to delete a charge
if (isset($_POST['charge_delete_submit'])) {
    $delete = $_POST['charge'];
    include '../include/conn.php';
    $sql = "DELETE FROM org_charge WHERE org_id = ? AND charge_code = ?";
    $deleteStatement = mysqli_prepare($conn, $sql);
    if ($deleteStatement) {
        mysqli_stmt_bind_param($deleteStatement, 'ss', $username, $delete);
        mysqli_stmt_execute($deleteStatement);
        echo "<h4 class='text-center'>Charge Deleted Successfully!</h4>";
        mysqli_stmt_close($deleteStatement);
    } else {
        echo "<h4 class='text-center'>Error Deleting Charge!</h4>";
    }
    mysqli_close($conn);
}

// Check if the form to edit a charge has been submitted
if (isset($_POST['charge_edit']) || isset($_POST['charge_edit_submit']) || isset($_POST['update_charge_submit'])) {
    ?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Edit Charge</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <select class="form-control" name="charge">
                        <option value="">-- Select Charge to Edit --</option>
                        <?php
                        include '../include/conn.php';
                        $search = "SELECT * FROM org_charge WHERE org_id = ?";
                        $searchStatement = mysqli_prepare($conn, $search);
                        if ($searchStatement) {
                            mysqli_stmt_bind_param($searchStatement, 's', $username);
                            mysqli_stmt_execute($searchStatement);
                            $result = mysqli_stmt_get_result($searchStatement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $charge_name = $row['charge_name'];
                                $charge_code = $row['charge_code'];
                                $charge_amount = $row['charge_amount'];
                                ?>
                                <option value="<?php echo $charge_code; ?>"><?php echo $count . ". " . $charge_name . " " . $charge_code . " " . $charge_amount; ?></option>
                                <?php
                            }
                            mysqli_stmt_close($searchStatement);
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="charge_edit_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
    <?php
}

// Handle form submission to get the charge details for editing
if (isset($_POST['charge_edit_submit']) || isset($_POST['update_charge_submit'])) {
    $charge = $_POST['charge'];
    
    include '../include/conn.php';
    
    $sql = "SELECT * FROM org_charge WHERE org_id = ? AND charge_code = ?";
    $selectStatement = mysqli_prepare($conn, $sql);
    if ($selectStatement) {
        mysqli_stmt_bind_param($selectStatement, 'ss', $username, $charge);
        mysqli_stmt_execute($selectStatement);
        $result = mysqli_stmt_get_result($selectStatement);
        $row = mysqli_fetch_assoc($result);
        $charge_name = $row['charge_name'];
        $charge_code = $row['charge_code'];
        $charge_amount = $row['charge_amount'];
        ?>
        <div class="col-sm-12">
            <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Update Charge</i></h4>
            <br>
        </div>
        <div class="col-sm-12">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-sm-3 form-group">
                        <input type="text" class="form-control" name="charge_name" value="<?php echo $charge_name; ?>">
                    </div>
                    <div class="col-sm-3 form-group">
                        <input type="text" class="form-control" name="charge_amount" value="<?php echo $charge_amount; ?>">
                    </div>
                    <input type="hidden" class="form-control" name="charge_code" value="<?php echo $charge_code; ?>">
                    <div class="col-sm-3 form-group">
                        <input type="submit" class="form-control approve" name="update_charge_submit" value="Update Charge">
                    </div>
                </div>
            </form>
        </div>
        <?php
        mysqli_stmt_close($selectStatement);
    }
    mysqli_close($conn);
}

// Handle form submission to update a charge
if (isset($_POST['update_charge_submit'])) {
    $charge_name = $_POST['charge_name'];
    $charge_code = $_POST['charge_code'];
    $charge_amount = $_POST['charge_amount'];
    
    include '../include/conn.php';
    
    $sql = "UPDATE org_charge SET charge_name = ?, charge_amount = ? WHERE org_id = ? AND charge_code = ?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if ($updateStatement) {
        mysqli_stmt_bind_param($updateStatement, 'ssss', $charge_name, $charge_amount, $username, $charge_code);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center'>Update Successful!</h4>";
        mysqli_stmt_close($updateStatement);
    } else {
        echo "<h4 class='text-center'>Error Updating Charge!</h4>";
    }
    mysqli_close($conn);
}
?>

<?php /*
	if(isset($_POST['charge_add']) || isset($_POST['charge_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Charge</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<input type="text" class="form-control" name="charge_name" placeholder="Charge Name...">
						</div>
						<div class="col-sm-3 form-group">
							<input type="text" class="form-control" name="charge_code" placeholder="Charge Code...">
						</div>
						<div class="col-sm-3 form-group">
							<input type="text" class="form-control" name="charge_amount" placeholder="Charge Amount...">
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="charge_submit" value="Add Charge">
						</div>
					</div>
				</form>
			</div>
		
	<?php
	}
	if(isset($_POST['charge_submit'])){
		$charge_name = $_POST['charge_name'];
		$charge_code = $_POST['charge_code'];
		$charge_amount = $_POST['charge_amount'];
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO org_charge(org_id,charge_name,charge_code,charge_amount)VALUES(?,?,?,?)";
		$insertStatment = mysqli_prepare($conn,$sql);
		if(!$insertStatment){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatment,'ssss',$username,$charge_name,$charge_code,$charge_amount);
			mysqli_stmt_execute($insertStatment);
			echo "<h4 class='text-center'>Charge Added Successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['charge_del']) || isset($_POST['charge_delete_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Delete Charge</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<select class="form-control" name="charge">
								<option value="">-- Select Charge to Delete --</option>
								<?php
									include '../include/conn.php';
									$search = "SELECT * FROM org_charge WHERE org_id = ?";
									$searchStatement = mysqli_prepare($conn,$search);
									if(!$searchStatement){
										echo "";
									}else{
										mysqli_stmt_bind_param($searchStatement,'s',$username);
										mysqli_stmt_execute($searchStatement);
										$result = mysqli_stmt_get_result($searchStatement);
										$count = 0;
										while($row = mysqli_fetch_assoc($result)){
											$count = $count + 1;
											$charge_name = $row['charge_name'];
											$charge_code = $row['charge_code'];
											$charge_amount = $row['charge_amount'];
											?>
												<option value="<?php echo $charge_code;?>"><?php echo $count.". ".$charge_name." ".$charge_code." ".$charge_amount;?></option>
											<?php
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="charge_delete_submit" value="Submit">
						</div>
					</div>
				</form>
			</div>
		
	<?php
	}
	if(isset($_POST['charge_delete_submit'])){
		$delete = $_POST['charge'];
		include '../include/conn.php';
		$sql = "DELETE FROM org_charge WHERE org_id = ? AND charge_code = ?";
		$deleteStatement = mysqli_prepare($conn,$sql);
		if(!$deleteStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($deleteStatement,'ss',$username,$delete);
			mysqli_stmt_execute($deleteStatement);
			echo "<h4 class='text-center'>Charge deleted successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['charge_edit']) || isset($_POST['charge_edit_submit']) || isset($_POST['update_charge_submit'])){
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Edit Charge</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<select class="form-control" name="charge">
								<option value="">-- Select Charge to Edit --</option>
								<?php
									include '../include/conn.php';
									$search = "SELECT * FROM org_charge WHERE org_id = ?";
									$searchStatement = mysqli_prepare($conn,$search);
									if(!$searchStatement){
										echo "";
									}else{
										mysqli_stmt_bind_param($searchStatement,'s',$username);
										mysqli_stmt_execute($searchStatement);
										$result = mysqli_stmt_get_result($searchStatement);
										$count = 0;
										while($row = mysqli_fetch_assoc($result)){
											$count = $count + 1;
											$charge_name = $row['charge_name'];
											$charge_code = $row['charge_code'];
											$charge_amount = $row['charge_amount'];
											?>
												<option value="<?php echo $charge_code;?>"><?php echo $count.". ".$charge_name." ".$charge_code." ".$charge_amount;?></option>
											<?php
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="charge_edit_submit" value="Submit">
						</div>
					</div>
				</form>
			</div>
		
<?php
	}
	if(isset($_POST['charge_edit_submit']) || isset($_POST['update_charge_submit'])){
		@$charge = $_POST['charge'];
		
		include '../include/conn.php';
		
		$sql = "SELECT * FROM org_charge WHERE org_id = ? AND charge_code =?";
		$selectStatement = mysqli_prepare($conn,$sql);
		if(!$selectStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($selectStatement,'ss',$username,$charge);
			mysqli_stmt_execute($selectStatement);
			$result = mysqli_stmt_get_result($selectStatement);
			$row = mysqli_fetch_assoc($result);
			@$charge_name = $row['charge_name'];
			@$charge_code = $row['charge_code'];
			@$charge_amount = $row['charge_amount'];
		
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Update Charge</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<input type="text" class="form-control" name="charge_name" value="<?php echo $charge_name;?>">
						</div>
						<div class="col-sm-3 form-group">
							<input type="text" class="form-control" name="charge_amount" value="<?php echo $charge_amount;?>">
						</div>
						<!--<div class="col-sm-4 form-group">-->
							<input type="hidden" class="form-control" name="charge_code" value="<?php echo $charge_code;?>">
						<!--</div>-->
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="update_charge_submit" value="Update Charge">
						</div>
					</div>
				</form>
			</div>
		
<?php
		}
	}
	if(isset($_POST['update_charge_submit'])){
		$charge_name = $_POST['charge_name'];
		$charge_code = $_POST['charge_code'];
		$charge_amount = $_POST['charge_amount'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE org_charge SET charge_name = ?, charge_amount = ? WHERE org_id = ? AND charge_code = ?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'ssss',$charge_name,$charge_amount,$username,$charge_code);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 clas='text-center'>Update Successful!</h4>";
			mysqli_close($conn);
		}
	}*/
?>
<?php
	if(isset($_POST['payroll_approve'])){
		$employee_id = $_POST['to_pay'];
		$additions = $_POST['allowance'];
		$deductions = $_POST['deductions'];
		$tax = $_POST['tax'];
		?>
		<h3>Payroll Summary</h3>
		<div class="row gens">
			<table>
				<thead>
					<tr>
						<th>#</th>
						<th>Employee ID</th>
						<th>Statutory Deductions</th>
						<th>Allowances</th>
						<th>Net Pay</th>
					</tr>
				</thead>
			<?php
			echo $employee_id;
			echo $additions;
			echo $deductions;
			echo $tax;
			?>
				<tbody>
				<?php
					if(){
						
					}
				?>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php
	}
?>
<?php

// Check if session variable is set
if (!isset($_SESSION['username'])) {
    die("Access denied: No user session found.");
}

include '../include/conn.php';

// Function to display department options
function display_department_options($conn, $username) {
    $sql = "SELECT * FROM org_department WHERE org_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $count = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $count++;
            $department_name = htmlspecialchars($row['department_name']);
            $department_code = htmlspecialchars($row['department_code']);
            echo "<option value='{$department_code}'>{$count}. {$department_name} {$department_code}</option>";
        }
        mysqli_stmt_close($stmt);
    }
}

if (isset($_POST['department_add']) || isset($_POST['department_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Department</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <input type="text" class="form-control" name="department_name" placeholder="Department Name..." required>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="text" class="form-control" name="department_code" placeholder="Department Code..." required>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="department_submit" value="Add Department">
                </div>
            </div>
        </form>
    </div>
<?php
}

if (isset($_POST['department_submit'])) {
    $department_name = htmlspecialchars($_POST['department_name']);
    $department_code = htmlspecialchars($_POST['department_code']);

    $sql = "INSERT INTO org_department(org_id, department_name, department_code) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sss', $username, $department_name, $department_code);
        mysqli_stmt_execute($stmt);
        echo "<h4 class='text-center'>Department Added Successfully!</h4>";
        mysqli_stmt_close($stmt);
    } else {
        echo "<h4 class='text-center'>Error: Unable to add department.</h4>";
    }
}

if (isset($_POST['department_del']) || isset($_POST['department_delete_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Delete Department</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-4 form-group">
                    <select class="form-control" name="department" required>
                        <option value="">-- Select Department to Delete --</option>
                        <?php display_department_options($conn, $username); ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="department_delete_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
<?php
}

if (isset($_POST['department_delete_submit'])) {
    $department_code = htmlspecialchars($_POST['department']);

    $sql = "DELETE FROM org_department WHERE org_id = ? AND department_code = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ss', $username, $department_code);
        mysqli_stmt_execute($stmt);
        echo "<h4 class='text-center'>Department deleted successfully!</h4>";
        mysqli_stmt_close($stmt);
    } else {
        echo "<h4 class='text-center'>Error: Unable to delete department.</h4>";
    }
}

if (isset($_POST['department_edit']) || isset($_POST['department_edit_submit']) || isset($_POST['update_department_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Edit Department</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-4 form-group">
                    <select class="form-control" name="department" required>
                        <option value="">-- Select Department to Edit --</option>
                        <?php display_department_options($conn, $username); ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="department_edit_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
<?php
}

if (isset($_POST['department_edit_submit']) || isset($_POST['update_department_submit'])) {
    $department_code = htmlspecialchars($_POST['department']);
    $sql = "SELECT * FROM org_department WHERE org_id = ? AND department_code = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ss', $username, $department_code);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        if ($row) {
            $department_name = htmlspecialchars($row['department_name']);
        }
        mysqli_stmt_close($stmt);
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Update Department</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-4 form-group">
                    <input type="text" class="form-control" name="department_name" value="<?php echo $department_name; ?>" required>
                </div>
                <input type="hidden" class="form-control" name="department_code" value="<?php echo $department_code; ?>">
                <div class="col-sm-4 form-group">
                    <input type="submit" class="form-control approve" name="update_department_submit" value="Update Department">
                </div>
            </div>
        </form>
    </div>
<?php
    }
}

if (isset($_POST['update_department_submit'])) {
    $department_name = htmlspecialchars($_POST['department_name']);
    $department_code = htmlspecialchars($_POST['department_code']);

    $sql = "UPDATE org_department SET department_name = ? WHERE org_id = ? AND department_code = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sss', $department_name, $username, $department_code);
        mysqli_stmt_execute($stmt);
        echo "<h4 class='text-center'>Update Successful!</h4>";
        mysqli_stmt_close($stmt);
    } else {
        echo "<h4 class='text-center'>Error: Unable to update department.</h4>";
    }
}

mysqli_close($conn);
?>

<?php /*
	if(isset($_POST['department_add']) || isset($_POST['department_submit'])){
	?>
	<div class="col-sm-12">
		<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Department</i></h4>
		<br>
	</div>
	<div class="col-sm-12">
		<form action="" method="POST">
			<div class="row">
				<div class="col-sm-3 form-group">
					<input type="text" class="form-control" name="department_name" placeholder="Department Name...">
				</div>
				<div class="col-sm-3 form-group">
					<input type="text" class="form-control" name="department_code" placeholder="Department Code...">
				</div>
				<div class="col-sm-3 form-group">
					<input type="submit" class="form-control approve" name="department_submit" value="Add Department">
				</div>
			</div>
		</form>
	</div>
		
	<?php
	}
	if(isset($_POST['department_submit'])){
		$department_name = $_POST['department_name'];
		$department_code = $_POST['department_code'];
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO org_department(org_id,department_name,department_code)VALUES(?,?,?)";
		$insertStatment = mysqli_prepare($conn,$sql);
		if(!$insertStatment){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatment,'sss',$username,$department_name,$department_code);
			mysqli_stmt_execute($insertStatment);
			echo "<h4 class='text-center'>Department Added Successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['department_del']) || isset($_POST['department_delete_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Delete Department</i></h4>
			<br>
		</div>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-4 form-group">
						<select class="form-control" name="department">
							<option value="">-- Select Department to Delete --</option>
							<?php
								include '../include/conn.php';
								$search = "SELECT * FROM org_department WHERE org_id = ?";
								$searchStatement = mysqli_prepare($conn,$search);
								if(!$searchStatement){
									echo "";
								}else{
									mysqli_stmt_bind_param($searchStatement,'s',$username);
									mysqli_stmt_execute($searchStatement);
									$result = mysqli_stmt_get_result($searchStatement);
									$count = 0;
									while($row = mysqli_fetch_assoc($result)){
										$count = $count + 1;
										$department_name = $row['department_name'];
										$department_code = $row['department_code'];
									?>
										<option value="<?php echo $department_code;?>"><?php echo $count.". ".$department_name." ".$department_code;?></option>
									<?php
									}
								}
							?>
						</select>
					</div>
					<div class="col-sm-3 form-group">
						<input type="submit" class="form-control approve" name="department_delete_submit" value="Submit">
					</div>
				</div>
			</form>
		</div>
	<?php
	}
	if(isset($_POST['department_delete_submit'])){
		$delete = $_POST['department'];
		include '../include/conn.php';
		$sql = "DELETE FROM org_department WHERE org_id = ? AND department_code = ?";
		$deleteStatement = mysqli_prepare($conn,$sql);
		if(!$deleteStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($deleteStatement,'ss',$username,$delete);
			mysqli_stmt_execute($deleteStatement);
			echo "<h4 class='text-center'>Department deleted successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['department_edit']) || isset($_POST['department_edit_submit']) || isset($_POST['update_department_submit'])){
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Edit Department</i></h4>
			<br>
		</div>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-4 form-group">
						<select class="form-control" name="department">
							<option value="">-- Select Department to Edit --</option>
							<?php
								include '../include/conn.php';
								$search = "SELECT * FROM org_department WHERE org_id = ?";
								$searchStatement = mysqli_prepare($conn,$search);
								if(!$searchStatement){
									echo "";
								}else{
									mysqli_stmt_bind_param($searchStatement,'s',$username);
									mysqli_stmt_execute($searchStatement);
									$result = mysqli_stmt_get_result($searchStatement);
									$count = 0;
									while($row = mysqli_fetch_assoc($result)){
										$count = $count + 1;
										$department_name = $row['department_name'];
										$department_code = $row['department_code'];
										?>
										<option value="<?php echo $department_code;?>"><?php echo $count.". ".$department_name." ".$department_code;?></option>
										<?php
									}
								}
							?>
						</select>
					</div>
					<div class="col-sm-3 form-group">
						<input type="submit" class="form-control approve" name="department_edit_submit" value="Submit">
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
	}
	if(isset($_POST['department_edit_submit']) || isset($_POST['update_department_submit'])){
		@$department = $_POST['department'];
		
		include '../include/conn.php';
		
		$sql = "SELECT * FROM org_department WHERE org_id = ? AND department_code =?";
		$selectStatement = mysqli_prepare($conn,$sql);
		if(!$selectStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($selectStatement,'ss',$username,$department);
			mysqli_stmt_execute($selectStatement);
			$result = mysqli_stmt_get_result($selectStatement);
			$row = mysqli_fetch_assoc($result);
			@$department_name = $row['department_name'];
			@$department_code = $row['department_code'];
		
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Update Department</i></h4>
			<br>
		</div>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-4 form-group">
						<input type="text" class="form-control" name="department_name" value="<?php echo $department_name;?>">
					</div>
					<!--<div class="col-sm-4 form-group">-->
						<input type="hidden" class="form-control" name="department_code" value="<?php echo $department_code;?>">
					<!--</div>-->
					<div class="col-sm-4 form-group">
						<input type="submit" class="form-control approve" name="update_department_submit" value="Update Department">
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
		}
	}
	if(isset($_POST['update_department_submit'])){
		$department_name = $_POST['department_name'];
		$department_code = $_POST['department_code'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE org_department SET department_name = ? WHERE org_id = ? AND department_code = ?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'sss',$department_name,$username,$department_code);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 clas='text-center'>Update Successful!</h4>";
			mysqli_close($conn);
		}
	}*/
?>
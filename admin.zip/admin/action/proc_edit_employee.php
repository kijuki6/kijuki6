<?php
if (isset($_POST['update_employee_submit'])) {
    // Retrieve and sanitize form data
    $fname = htmlspecialchars($_POST['add_fname']);
    $lname = htmlspecialchars($_POST['add_lname']);
    $oname = htmlspecialchars($_POST['add_oname']);
    $id = htmlspecialchars($_POST['add_id']);
    $phone = htmlspecialchars($_POST['add_phone']);
    $dob = htmlspecialchars($_POST['add_dob']);
    $email = htmlspecialchars($_POST['add_email']);
    $address = htmlspecialchars($_POST['add_address']);
    $user_id = md5($id);

    // Include database connection
    include '../include/conn.php';

    // Log directory and file creation
    $log_dir = "../admin/logs/employee_management/" . $organisation_name . "_" . $org_tpin . "/edit_employee/";
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    $log_file = $log_dir . "edit_employee.txt";
    // Check if the log file is empty and add column headings
    if (!file_exists($log_file) || filesize($log_file) === 0) {
        file_put_contents($log_file, sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", "Date/Time", "Full Name", "ID#", "Phone#", "DOB", "Email Address", "Home Address"), FILE_APPEND);
    }
    // Append updated employee data to the log file
    $date = date("Y-m-d H:i:s");
    file_put_contents($log_file, sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", $date, $fname . " " . $lname, $id, $phone, $dob, $email, $address), FILE_APPEND);

    // Create directories for employee data if they do not exist
    $employee_dir = "documents/organisations/" . $organisation_name . "_" . $username . "/employee_data/" . $user_id;
    if (!file_exists($employee_dir)) {
        mkdir($employee_dir, 0777, true);
    }

    // Update employee data
    $sql = "UPDATE org_emp_management SET fname=?, lname=?, oname=?, phone=?, dob=?, email=?, address=? WHERE employee_id=? AND org_id=?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if (!$updateStatement) {
        echo mysqli_error($conn);
    } else {
        mysqli_stmt_bind_param($updateStatement, 'sssssssss', $fname, $lname, $oname, $phone, $dob, $email, $address, $id, $username);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center' style='color: #50c878;'>***Employee Successfully Updated!***</h4>";
        mysqli_close($conn);
    }
}
?>

<?php
// Check if the form to add a new position has been submitted
if (isset($_POST['position_add']) || isset($_POST['position_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Add Position to Organisation"><i>Add Position</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <label>Department</label>
                    <select class="form-control" name="department_code">
                        <option value="">-- Select Department --</option>
                        <?php
                        include '../include/conn.php';
                        
                        $sql_read = "SELECT * FROM org_department WHERE org_id = ?";
                        $read_Statement = mysqli_prepare($conn, $sql_read);
                        if ($read_Statement) {
                            mysqli_stmt_bind_param($read_Statement, 's', $username);
                            mysqli_stmt_execute($read_Statement);
                            $result = mysqli_stmt_get_result($read_Statement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $department_name = $row['department_name'];
                                $department_code = $row['department_code'];
                                echo "<option value=\"$department_code\">$count. $department_name</option>";
                            }
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <label>Position Name</label>
                    <input type="text" class="form-control" name="position_name" placeholder="Position Name...">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Position Code</label>
                    <input type="text" class="form-control" name="position_code" placeholder="Position Code...">
                </div>
                <div class="col-sm-3 form-group">
                    <br>
                    <input type="submit" class="form-control approve" name="position_submit" value="Add Position">
                </div>
            </div>
        </form>
    </div>
<?php
}

// Handle form submission to add a new position
if (isset($_POST['position_submit'])) {
    $position_name = $_POST['position_name'];
    $position_code = $_POST['position_code'];
    $department_code = $_POST['department_code'];
    
    include '../include/conn.php';
    
    $sql = "INSERT INTO org_position(org_id, position_name, position_code, department_code) VALUES(?, ?, ?, ?)";
    $insertStatement = mysqli_prepare($conn, $sql);
    if ($insertStatement) {
        mysqli_stmt_bind_param($insertStatement, 'ssss', $username, $position_name, $position_code, $department_code);
        mysqli_stmt_execute($insertStatement);
        echo "<h4 class='text-center'>Position Added Successfully!</h4>";
        mysqli_close($conn);
    }
}

// Check if the form to delete a position has been submitted
if (isset($_POST['position_del']) || isset($_POST['position_delete_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Delete Position from Organisation"><i>Delete Position</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <select class="form-control" name="position">
                        <option value="">-- Select Position to Delete --</option>
                        <?php
                        include '../include/conn.php';
                        $search = "SELECT * FROM org_position WHERE org_id = ?";
                        $searchStatement = mysqli_prepare($conn, $search);
                        if ($searchStatement) {
                            mysqli_stmt_bind_param($searchStatement, 's', $username);
                            mysqli_stmt_execute($searchStatement);
                            $result = mysqli_stmt_get_result($searchStatement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $position_name = $row['position_name'];
                                $position_code = $row['position_code'];
                                echo "<option value=\"$position_code\">$count. $position_name $position_code</option>";
                            }
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="position_delete_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
<?php
}

// Handle form submission to delete a position
if (isset($_POST['position_delete_submit'])) {
    $delete = $_POST['position'];
    include '../include/conn.php';
    $sql = "DELETE FROM org_position WHERE org_id = ? AND position_code = ?";
    $deleteStatement = mysqli_prepare($conn, $sql);
    if ($deleteStatement) {
        mysqli_stmt_bind_param($deleteStatement, 'ss', $username, $delete);
        mysqli_stmt_execute($deleteStatement);
        echo "<h4 class='text-center'>Position Deleted Successfully!</h4>";
        mysqli_close($conn);
    }
}

// Check if the form to edit a position has been submitted
if (isset($_POST['position_edit']) || isset($_POST['position_edit_submit']) || isset($_POST['update_position_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Edit Position in Organisation"><i>Edit Position</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <select class="form-control" name="position">
                        <option value="">-- Select Position to Edit --</option>
                        <?php
                        include '../include/conn.php';
                        $search = "SELECT * FROM org_position WHERE org_id = ?";
                        $searchStatement = mysqli_prepare($conn, $search);
                        if ($searchStatement) {
                            mysqli_stmt_bind_param($searchStatement, 's', $username);
                            mysqli_stmt_execute($searchStatement);
                            $result = mysqli_stmt_get_result($searchStatement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $position_name = $row['position_name'];
                                $position_code = $row['position_code'];
                                echo "<option value=\"$position_code\">$count. $position_name $position_code</option>";
                            }
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="position_edit_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
<?php
}

// Handle form submission to get the position details for editing
if (isset($_POST['position_edit_submit']) || isset($_POST['update_position_submit'])) {
    $position = $_POST['position'];
    
    include '../include/conn.php';
    
    $sql = "SELECT * FROM org_position WHERE org_id = ? AND position_code = ?";
    $selectStatement = mysqli_prepare($conn, $sql);
    if ($selectStatement) {
        mysqli_stmt_bind_param($selectStatement, 'ss', $username, $position);
        mysqli_stmt_execute($selectStatement);
        $result = mysqli_stmt_get_result($selectStatement);
        $row = mysqli_fetch_assoc($result);
        $position_name = $row['position_name'];
        $position_code = $row['position_code'];
?>
        <div class="col-sm-12">
            <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Update Position in Organisation"><i>Update Position</i></h4>
            <br>
        </div>
        <div class="col-sm-12">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-sm-4 form-group">
                        <input type="text" class="form-control" name="position_name" value="<?php echo $position_name; ?>">
                    </div>
                    <input type="hidden" class="form-control" name="position_code" value="<?php echo $position_code; ?>">
                    <div class="col-sm-3 form-group">
                        <input type="submit" class="form-control approve" name="update_position_submit" value="Update Position">
                    </div>
                </div>
            </form>
        </div>
<?php
        mysqli_close($conn);
    }
}

// Handle form submission to update a position
if (isset($_POST['update_position_submit'])) {
    $position_name = $_POST['position_name'];
    $position_code = $_POST['position_code'];
    
    include '../include/conn.php';
    
    $sql = "UPDATE org_position SET position_name = ? WHERE org_id = ? AND position_code = ?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if ($updateStatement) {
        mysqli_stmt_bind_param($updateStatement, 'sss', $position_name, $username, $position_code);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center'>Update Successful!</h4>";
        mysqli_close($conn);
    }
}
?>

<?php /*
	if(isset($_POST['position_add']) || isset($_POST['position_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Add Employee to Organisation Payroll"><i>Add Position</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<label>Department</label>
							<select class="form-control" name="department_code">
								<option value="">-- Select Department --</option>
								<?php
									include '../include/conn.php';
									
									$sql_read = "SELECT * FROM org_department WHERE org_id = ?";
									$read_Statement = mysqli_prepare($conn,$sql_read);
									if(!$read_Statement){
										echo "";
									}else{
										mysqli_stmt_bind_param($read_Statement,'s',$username);
										mysqli_stmt_execute($read_Statement);
										$result = mysqli_stmt_get_result($read_Statement);
										$count = 0;
										while($row = mysqli_fetch_assoc($result)){
											$count = $count + 1;
											$department_name = $row['department_name'];
											$department_code = $row['department_code'];
										?>
											<option value="<?php echo $department_code;?>"><?php echo $count.". ".$department_name;?></option>
										<?php
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-3 form-group">
							<label>Position Name</label>
							<input type="text" class="form-control" name="position_name" placeholder="Position Name...">
						</div>
						<div class="col-sm-3 form-group">
							<label>Position Code</label>
							<input type="text" class="form-control" name="position_code" placeholder="Position Code...">
						</div>
						<div class="col-sm-3 form-group">
							<br>
							<input type="submit" class="form-control approve" name="position_submit" value="Add Position">
						</div>
					</div>
				</form>
			</div>
		
	<?php
	}
	if(isset($_POST['position_submit'])){
		$position_name = $_POST['position_name'];
		$position_code = $_POST['position_code'];
		$department_code = $_POST['department_code'];
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO org_position(org_id,position_name,position_code,department_code)VALUES(?,?,?,?)";
		$insertStatment = mysqli_prepare($conn,$sql);
		if(!$insertStatment){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatment,'ssss',$username,$position_name,$position_code,$department_code);
			mysqli_stmt_execute($insertStatment);
			echo "<h4 class='text-center'>Position Added Successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['position_del']) || isset($_POST['position_delete_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Add Employee to Organisation Payroll"><i>Delete Position</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<select class="form-control" name="position">
								<option value="">-- Select Position to Delete --</option>
								<?php
									include '../include/conn.php';
									$search = "SELECT * FROM org_position WHERE org_id = ?";
									$searchStatement = mysqli_prepare($conn,$search);
									if(!$searchStatement){
										echo "";
									}else{
										mysqli_stmt_bind_param($searchStatement,'s',$username);
										mysqli_stmt_execute($searchStatement);
										$result = mysqli_stmt_get_result($searchStatement);
										$count = 0;
										while($row = mysqli_fetch_assoc($result)){
											$count = $count + 1;
											$position_name = $row['position_name'];
											$position_code = $row['position_code'];
											?>
												<option value="<?php echo $position_code;?>"><?php echo $count.". ".$position_name." ".$position_code;?></option>
											<?php
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="position_delete_submit" value="Submit">
						</div>
					</div>
				</form>
			</div>
		
	<?php
	}
	if(isset($_POST['position_delete_submit'])){
		$delete = $_POST['position'];
		include '../include/conn.php';
		$sql = "DELETE FROM org_position WHERE org_id = ? AND position_code = ?";
		$deleteStatement = mysqli_prepare($conn,$sql);
		if(!$deleteStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($deleteStatement,'ss',$username,$delete);
			mysqli_stmt_execute($deleteStatement);
			echo "<h4 class='text-center'>Position deleted successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['position_edit']) || isset($_POST['position_edit_submit']) || isset($_POST['update_position_submit'])){
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Add Employee to Organisation Payroll"><i>Edit Position</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<select class="form-control" name="position">
								<option value="">-- Select Position to Edit --</option>
								<?php
									include '../include/conn.php';
									$search = "SELECT * FROM org_position WHERE org_id = ?";
									$searchStatement = mysqli_prepare($conn,$search);
									if(!$searchStatement){
										echo "";
									}else{
										mysqli_stmt_bind_param($searchStatement,'s',$username);
										mysqli_stmt_execute($searchStatement);
										$result = mysqli_stmt_get_result($searchStatement);
										$count = 0;
										while($row = mysqli_fetch_assoc($result)){
											$count = $count + 1;
											$position_name = $row['position_name'];
											$position_code = $row['position_code'];
											?>
												<option value="<?php echo $position_code;?>"><?php echo $count.". ".$position_name." ".$position_code;?></option>
											<?php
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="position_edit_submit" value="Submit">
						</div>
					</div>
				</form>
			</div>
		
<?php
	}
	if(isset($_POST['position_edit_submit']) || isset($_POST['update_position_submit'])){
		@$position = $_POST['position'];
		
		include '../include/conn.php';
		
		$sql = "SELECT * FROM org_position WHERE org_id = ? AND position_code =?";
		$selectStatement = mysqli_prepare($conn,$sql);
		if(!$selectStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($selectStatement,'ss',$username,$position);
			mysqli_stmt_execute($selectStatement);
			$result = mysqli_stmt_get_result($selectStatement);
			$row = mysqli_fetch_assoc($result);
			@$position_name = $row['position_name'];
			@$position_code = $row['position_code'];
		
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Add Employee to Organisation Payroll"><i>Update Position</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-4 form-group">
							<input type="text" class="form-control" name="position_name" value="<?php echo $position_name;?>">
						</div>
						<!--<div class="col-sm-4 form-group">-->
							<input type="hidden" class="form-control" name="position_code" value="<?php echo $position_code;?>">
						<!--</div>-->
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="update_postion_submit" value="Update Position">
						</div>
					</div>
				</form>
			</div>
		
<?php
		}
	}
	if(isset($_POST['update_postion_submit'])){
		$position_name = $_POST['position_name'];
		$position_code = $_POST['position_code'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE org_position SET position_name = ? WHERE org_id = ? AND position_code = ?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'sss',$position_name,$username,$position_code);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 clas='text-center'>Update Successful!</h4>";
			mysqli_close($conn);
		}
	}*/
?>
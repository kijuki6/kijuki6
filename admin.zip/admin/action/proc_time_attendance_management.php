<?php
	if(isset($_POST['time_add']) || isset($_POST['time'])){
		?>
			<div class="col-sm-12">
				<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Time</h4>
				<br>
			</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<label for="clock_in">Clock-In Time</label>
							<input type="time" class="form-control" name="clock_in" placeholder="Clock-In Time" required>
						</div>
						<div class="col-sm-3 form-group">
							<label for="clock_out">Clock-Out Time</label>
							<input type="time" class="form-control" name="clock_out" placeholder="Clock-Out Time" required>
						</div>
						<div class="col-sm-3 form-group">
							<label for="lunch">Lunch Duration</label>
							<input type="number" class="form-control" name="lunch" id="lunch" placeholder="Lunch Duration..." required>
						</div>
						<div class="col-sm-3 form-group">
							<label for="max_time">Max-Work Hours</label>
							<input type="number" class="form-control" maxlength="2" name="max_time" id="max_time" placeholder="Max-Work Hours" required>
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="time" value="Add Time">
						</div>
					</div>
				</form>
				<br>
				<div class="" style="border: 1px solid #000; padding: 10px;">
					<p><b><i>**Clock-In Time is the earliest time that an employee can check in to work the maximum number of hours allowed**</i></b></p>
					<p><b><i>**Clock-Out Time is the latest time that an employee can check out and worked the maximum number of hours allowed**</i></b></p>
					<p><i>** When you add time, it is updated in the system. No new times are actually added that would confuse the settings and setup of the system **</i></p>
				</div>
			</div>
		<?php
	}
	if(isset($_POST['time'])){
		$clock_in = $_POST['clock_in'];
		$clock_out = $_POST['clock_out'];
		$lunch = $_POST['lunch'];
		$max_time = $_POST['max_time'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE org_time_attendance SET clock_in = ?, clock_out = ?, lunch = ?, max_hours = ? WHERE org_id = ?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo mysqli_error($conn);
		}else{
			mysqli_stmt_bind_param($updateStatement,'sssss',$clock_in,$clock_out,$lunch,$max_time,$username);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 style='color: #50c878; text-align: center;'>Time and Attendance has been successfully updated!</h4>";
			mysqli_close($conn);
		}
	}
?>

<div class="container-fluid">
	<div class="row">
		<div class="row">
			<div class="col-sm-10 topbar">
				<h1>Green Pine Payroll System | [Org Name]</h1>
			</div>
			<div class="col-sm-2 topbar topbar-button"><a href="../logout.php"><button class="logout-button">Logout</button></a></div>
			<div class="col-sm-12">
				<hr class="separator">
			</div>
		</div>
		<div class="col-sm-3 sidebar">
			<a href="dashboard.php"><button class="side-button"><i class="fa fa-home" aria-hidden="true"></i> Dashboard</button></a>
			<a href="employee_management.php"><button class="side-button"><i class="fa fa-users" aria-hidden="true"></i> Employee Management</button></a>
			<a href="allowance_management.php"><button class="side-button"><i class="fa fa-database" aria-hidden="true"></i> Allowance Management</button></a>
			<a href="department_management.php"><button class="side-button"><i class="fa fa-list-ol" aria-hidden="true"></i> Department Management</button></a>
			<a href="position_management.php"><button class="side-button"><i class="fa fa-arrows-v" aria-hidden="true"></i> Position Management</button></a>
			<a href="salary_management.php"><button class="side-button"><i class="fa fa-gbp" aria-hidden="true"></i> Salary Management</button></a>
			<a href="charge_management.php"><button class="side-button"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Management</button></a>
			<a href="time_attendance_management.php"><button class="side-button"><i class="fa fa-clock-o" aria-hidden="true"></i> Time &amp; Attendance Management</button></a>
			<a href="payroll_management.php"><button class="side-button active"><i class="fa fa-usd" aria-hidden="true"></i> Payroll Management</button></a>
		</div>
		<div class="col-sm-9 dashboardf">
			<h4 style="font-size: 3em; padding: 10px;">Payroll History</h4>
			<div class="row" style="background-color: #1e293b;">				
				<div class="col-sm-3 form-group">
					<br>
					<a href="payroll_management.php"><button class="form-control approve">&#60;&#60; BACK</button></a>
				</div>
				<div class="col-sm-4 form-group" style="background-color: #e7e7e7;">
					<br>
					<p class="text-center" style="padding: 5px; font-weight: bold;">PAYROLL BUDGET: ZMW
						<?php
							
							include "../include/conn.php";
							
							$sql = "SELECT SUM(net_pay) as total_pay FROM temp_table_id WHERE org_id = ?";
							$payroll_budget = mysqli_prepare($conn,$sql);
							
								mysqli_stmt_bind_param($payroll_budget,'s',$username);
								mysqli_stmt_execute($payroll_budget);
								$result = mysqli_stmt_get_result($payroll_budget);
								$sum = 0;
								while($row = mysqli_fetch_assoc($result)){
									$net_pay = $row['total_pay'];
									echo $net_pay;
								}
						?>
					</p>
			
				</div>
			</div>
			<div class="row" style="padding: 5px;">
				<div class="col-sm-12">
					<?php
			
					include '../include/conn.php';
					$sql = "SELECT image_link FROM org_folder_year_payslips WHERE org_id = ?";
					$images = mysqli_prepare($conn,$sql);
					if(!$images){
						echo "";
					}else{
						mysqli_stmt_bind_param($images,'s',$username);
						mysqli_stmt_execute($images);
						$result = mysqli_stmt_get_result($images);
						$row = mysqli_fetch_assoc($result);
						@$in_folder_icon = $_SESSION['icon'] = $row['image_link'];
					}
					
					$sql = "SELECT * FROM org_folder WHERE org_id = ?";
					$read = mysqli_prepare($conn,$sql);
					if(!$read){
						echo "";
					}else{
						mysqli_stmt_bind_param($read,'s',$username);
						mysqli_stmt_execute($read);
						$result = mysqli_stmt_get_result($read);
						$row = mysqli_fetch_assoc($result);
						@$link = $row['link'];
						@$folder_name = $row['folder_name'];
						@$image = $row['image_link'];
						?>
						<h3 class="text-center"><span class="placard"><?php echo $folder_name;?></span></h3>			
					<br>
					<br>
				</div>
				<hr>
				<div class="col-sm-12">
					<div class="row">
						<div class="col-sm-2">
							<p class="">
								<form action="" method="POST">
									<button type="submit" name="to_summary_year"><?php echo $image;?></button><br>
									<?php //echo $folder_name;?>
								</form>
								<b>Payroll Summary</b>
							</p>
						</div>
						<div class="col-sm-2">
							<p class="">
								<form action="" method="POST">
									<button type="submit" name="to_payslip_year"><?php echo $image;?></button><br>
									<?php //echo $folder_name;?>
								</form>
								<b>Payslips</b>
							</p>
						</div>
					</div>
				</div>
				<?php
			}
			if(isset($_POST['to_summary_year']) || isset($_POST['to_month_summary']) || isset($_POST['to_payroll_summary'])){
				include '../include/conn.php';
				$sql = "SELECT * FROM org_folder_year_summary WHERE org_id = ?";
				$readStatement = mysqli_prepare($conn,$sql);
				if(!$readStatement){
					echo "";
				}else{
					mysqli_stmt_bind_param($readStatement,'s',$username);
					mysqli_stmt_execute($readStatement);
					$result = mysqli_stmt_get_result($readStatement);
				?>
					<hr>
					<h4>Payroll Summary History - Year</h4>
					<div class="col-sm-12">
						<div class="row">
					<?php	while($row = mysqli_fetch_assoc($result)){
								$year = $row['folder_name'];
								$icon = $row['image_link'];
							?>
									<div class="col-sm-2">
										<p>
											<form action="" method="POST">
												<input type="hidden" value="<?php echo $year;?>" name="year">
												<button type="submit" name="to_month_summary"><?php echo $icon;?></button>
											</form>
											<b><?php echo $year;?></b>
										</p>
									</div>
								<?php
							}
								?>
						</div>
					</div>
						<?php
				}
			}elseif(isset($_POST['to_payslip_year']) || isset($_POST['to_month_payslip']) || isset($_POST['to_payslips_history'])){
				$sql = "SELECT * FROM org_folder_year_payslips WHERE org_id = ?";
				$readStatement = mysqli_prepare($conn,$sql);
				if(!$readStatement){
					echo "";
				}else{
					mysqli_stmt_bind_param($readStatement,'s',$username);
					mysqli_stmt_execute($readStatement);
					$result = mysqli_stmt_get_result($readStatement);
					
						?>
							<hr>
							<h4>Payslip History - Year</h4>
							<div class="col-sm-12">
								<div class="row">
								<?php
									while($row = mysqli_fetch_assoc($result)){
										$year = $row['folder_name'];
										$icon = $row['image_link'];
										?>
										<div class="col-sm-2">
											<p>
												<form action="" method="POST">
													<input type="hidden" name="year" value="<?php echo $year;?>">
													<button type="submit" name="to_month_payslip"><?php echo $icon;?></button>
												</form>
												<b><?php echo $year;?></b>
											</p>
										</div>
								<?php
								}
								?>
								</div>
							</div>
						<?php
					
				}
			}else{
				//do nothing
			}
			
			//Month Summary
			if(isset($_POST['to_month_summary']) || isset($_POST['to_payroll_summary'])){
				@$year = $_POST['year'];
				$sql = "SELECT * FROM org_folder_month_summary WHERE org_id = ? AND folder_year = ?";
				$read = mysqli_prepare($conn,$sql);
				if(!$read){
					echo "";
				}else{
					mysqli_stmt_bind_param($read,'ss',$username,$year);
					mysqli_stmt_execute($read);
					$result = mysqli_stmt_get_result($read);
				?>
					<hr>
					<h4>Payroll Summary | Month</h4>
					<div class="col-sm-12">
						<div class="row">
						<?php	while($row = mysqli_fetch_assoc($result)){
									$month = $row['folder_month'];
								?>
									<div class="col-sm-2">
										<p>
											<form action="" method="POST">
												<input type="hidden" value="<?php echo $month;?>" name="month">
												<input type="hidden" value="<?php echo $year;?>" name="year">
												<button type="submit" name="to_payroll_summary"><?php echo $icon;?></button>
											</form>
											<b><?php echo $month;?></b>
										</p>
									</div>
								<?php
									}
								?>
						</div>
					</div>						
						<?php
					
				}
			}
			
			//View Payroll Summary
			if(isset($_POST['to_payroll_summary'])){
				$year = $_POST['year'];
				$month = $_POST['month'];
				$sql = "SELECT * FROM org_folder_file_summary WHERE org_id = ? AND folder_year = ? AND folder_month = ?";
				$read = mysqli_prepare($conn,$sql);
				if(!$read){
					echo "";
				}else{
					mysqli_stmt_bind_param($read,'sss',$username,$year,$month);
					mysqli_stmt_execute($read);
					$result = mysqli_stmt_get_result($read);
				?>
					<hr>
					<h4>Payroll Summary | By Date</h4>
					<div class="col-sm-12">
						<div class="row">
					<?php
						while($row = mysqli_fetch_assoc($result)){
							$file_name = $row['file_name'];
							$file_link = $row['file_link'];
							$icon = $row['image_link'];
						?>
							<div class="col-sm-2">
								<p>
									<a href="<?php echo $file_link;?>" download><button><?php echo $icon;?></button></a>
									<b><?php echo $file_name;?></b><br>
									<a href="<?php echo $file_link;?>" download><button class="btn"><i class="fa fa-download"></i> Download</button></a>
								</p>
							</div>
						<?php
						}
						?>
						</div>
					</div>
				<?php
				}
			}
			
			
			//Month Payslips
			if(isset($_POST['to_month_payslip']) || isset($_POST['to_payslips_history'])){
				@$year = $_POST['year'];
				$sql = "SELECT * FROM org_folder_month_payslips WHERE org_id = ? AND folder_year = ?";
				$read = mysqli_prepare($conn,$sql);
				if(!$read){
					echo "";
				}else{
					mysqli_stmt_bind_param($read,'ss',$username,$year);
					mysqli_stmt_execute($read);
					$result = mysqli_stmt_get_result($read);
				?>
					<hr>
					<h4>Payslips | Month</h4>
					<div class="col-sm-12">
						<div class="row">
						<?php		while($row = mysqli_fetch_assoc($result)){
									@$month = $row['folder_month'];
									$_SESSION['month'] = $month;
									$month_number = $_SESSION['month'];
								?>
									<div class="col-sm-2">
										<p>
											<form action="" method="POST">
												<input type="hidden" value="<?php echo $year;?>" name="year">
												<input type="hidden" value="<?php echo $month;?>" name="month">
												<button type="submit" name="to_payslips_history"><?php echo $in_folder_icon;?></button>
											</form>
											<b><?php echo $month_number;?></b>
										</p>
									</div>
								<?php
									}
									?>
						</div>
					</div>
						<?php
					
				}
			}
			
			
			
			//Payslips
			if(isset($_POST['to_payslips_history'])){
				$year = $_POST['year'];
				$month = $_POST['month'];
				$sql = "SELECT * FROM org_folder_file_payslips WHERE org_id = ? AND folder_year = ? AND folder_month = ?";
				$read = mysqli_prepare($conn,$sql);
				if(!$read){
					echo "";
				}else{
					mysqli_stmt_bind_param($read,'sss',$username,$year,$month);
					mysqli_stmt_execute($read);
					$result = mysqli_stmt_get_result($read);
				?>
					<hr>
					<h4>Payslip Collate | By Date</h4>
					<div class="col-sm-12">
						<div class="row">
					<?php
						while($row = mysqli_fetch_assoc($result)){
							$payslip_collated = $row['file_name'];
							$file_link = $row['file_link'];
							$icon = $row['image_link'];
						?>
							<div class="col-sm-2">
								<p>
									<a href="<?php echo $file_link;?>" download><button><?php echo $icon;?></button></a>
									<b><?php echo $payslip_collated;?></b><br>
									<a href="<?php echo $file_link;?>" download><button class="btn"><i class="fa fa-download"></i> Download</button></a>
								</p>
							</div>
						<?php
						}
						?>
						</div>
					</div>
				<?php
				}
			}
		?>
	
				
			</div>
		</div>
	</div>
</div>
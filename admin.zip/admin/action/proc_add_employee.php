<?php /*
	if(isset($_POST['add_employee_submit'])){
		$fname = $_POST['add_fname'];
		$lname = $_POST['add_lname'];
		$oname = $_POST['add_oname'];
		$id = $_POST['add_id'];
		$phone = $_POST['add_phone'];
		$dob = $_POST['add_dob'];
		$email = $_POST['add_email'];
		$address = $_POST['add_address'];
		$user_id = md5($id);
		
		
		include '../include/conn.php';
		$sql_check = "SELECT * FROM org_emp_management WHERE org_id = ? AND employee_id = ?";
		$check = mysqli_prepare($conn,$sql_check);
		if(!$check){
			echo "";
		}else{
			mysqli_stmt_bind_param($check,'ss',$username,$id);
			mysqli_stmt_execute($check);
			$result = mysqli_stmt_get_result($check);
			$row = mysqli_fetch_assoc($result);
			@$checked = $row['employee_id'];
				if($checked == $id){
					echo "<h4 class='text-center' style='color: #ff0000;'>Employee ID already exists!</h4>";
					mysqli_close($conn);
				}else{
					$sql = "INSERT INTO org_emp_management(org_id,fname,lname,oname,employee_id,phone,dob,email,address)
						VALUES(?,?,?,?,?,?,?,?,?)";
					$insertStatement = mysqli_prepare($conn,$sql);
					if(!$insertStatement){
						echo "";
					}else{
						mysqli_stmt_bind_param($insertStatement,'sssssssss',$username,$fname,$lname,$oname,$id,$phone,$dob,$email,$address);
						mysqli_stmt_execute($insertStatement);
						
						$log_dir = "../admin/logs/employee_management/".$organisation_name."_".$org_tpin."/";
						if (!file_exists($log_dir)) {
							mkdir($log_dir, 0777, true);
						}
						$log_file = $log_dir . "add_employee.txt";
						// Check if the log file is empty and add column headings
						if (!file_exists($log_file) || filesize($log_file) === 0) {
							file_put_contents($log_file, sprintf("%-20s %-30s %-30s %-15s %-30s %-30s $-20s $-30s $-30s\n", "Date Time", "First Name", "Last Name", "Other Name", "ID#", "Phone#", "DOB", "Email Address", "Home Address"), FILE_APPEND);
						}
						$file = fopen($log_file, "a");
						$t = time();
						$date = date("Y-m-d H:i:s", $t);
						fwrite($file, sprintf("%-20s %-30s %-30s %-15s %-30s %-30s $-20s $-30s $-30s\n", $date, $fname, $lname, $oname, $id, $phone, $dob, $email, $address));
						fclose($file);
						
						echo "<h4 class='text-center' style='color: #50c878;'>Employee Added Successfully!</h4>";
												
						mkdir("documents/organisations/".$organisation_name."_".$username."/employee_data/".$user_id,0777,true);
						mysqli_close($conn);
					}
				}
			}
		}
		*/
?>
<?php
if (isset($_POST['add_employee_submit'])) {
    // Retrieve and sanitize form data
    $fname = htmlspecialchars($_POST['add_fname']);
    $lname = htmlspecialchars($_POST['add_lname']);
    $oname = htmlspecialchars($_POST['add_oname']);
    $id = htmlspecialchars($_POST['add_id']);
    $phone = htmlspecialchars($_POST['add_phone']);
    $dob = htmlspecialchars($_POST['add_dob']);
    $email = htmlspecialchars($_POST['add_email']);
    $address = htmlspecialchars($_POST['add_address']);
    $user_id = md5($id);

    // Include database connection
    include '../include/conn.php';

    // Check if employee ID already exists
    $sql_check = "SELECT * FROM org_emp_management WHERE org_id = ? AND employee_id = ?";
    $check = mysqli_prepare($conn, $sql_check);
    if ($check) {
        mysqli_stmt_bind_param($check, 'ss', $username, $id);
        mysqli_stmt_execute($check);
        $result = mysqli_stmt_get_result($check);
        $row = mysqli_fetch_assoc($result);
        $checked = $row['employee_id'] ?? null;
        
        if ($checked === $id) {
            echo "<h4 class='text-center' style='color: #ff0000;'>Employee ID already exists!</h4>";
            mysqli_close($conn);
            exit;
        }
    } else {
        echo "<h4 class='text-center' style='color: #ff0000;'>Database error: Unable to prepare statement.</h4>";
        mysqli_close($conn);
        exit;
    }

    // Insert new employee data
    $sql = "INSERT INTO org_emp_management(org_id, fname, lname, oname, employee_id, phone, dob, email, address)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $insertStatement = mysqli_prepare($conn, $sql);
    if ($insertStatement) {
        mysqli_stmt_bind_param($insertStatement, 'sssssssss', $username, $fname, $lname, $oname, $id, $phone, $dob, $email, $address);
        mysqli_stmt_execute($insertStatement);

        // Log directory and file creation
        $log_dir = "../admin/logs/employee_management/" . $organisation_name . "_" . $org_tpin . "/add_employee/";
        if (!file_exists($log_dir)) {
            mkdir($log_dir, 0777, true);
        }
        $log_file = $log_dir . "add_employee.txt";
        // Check if the log file is empty and add column headings
        if (!file_exists($log_file) || filesize($log_file) === 0) {
            file_put_contents($log_file, sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", "Date/Time", "Full Name", "ID#", "Phone#", "DOB", "Email Address", "Home Address"), FILE_APPEND);
        }
        // Append new employee data to the log file
        $date = date("Y-m-d H:i:s");
        file_put_contents($log_file, sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", $date, $fname." ".$lname, $id, $phone, $dob, $email, $address), FILE_APPEND);

        echo "<h4 class='text-center' style='color: #50c878;'>***Employee Added Successfully!***</h4>";

        // Create directories for employee data if they do not exist
        $employee_dir = "documents/organisations/" . $organisation_name . "_" . $username . "/employee_data/" . $user_id;
        if (!file_exists($employee_dir)) {
            mkdir($employee_dir, 0777, true);
        }

        mysqli_close($conn);
    } else {
        echo "<h4 class='text-center' style='color: #ff0000;'>Database error: Unable to prepare statement.</h4>";
        mysqli_close($conn);
    }
}
?>

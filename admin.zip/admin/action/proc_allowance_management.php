<?php
if (isset($_POST['allowance_add']) || isset($_POST['allowance_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Allowance</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <label>Housing Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_housing" placeholder="Allowance Name Rate(%)...">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Transport Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_transport" placeholder="Allowance Code Rate(%)...">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Lunch Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_lunch" placeholder="Allowance Lunch Rate(%)...">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Medical Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_medical" placeholder="Allowance Medical Rate(%)...">
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="allowance_submit" value="Add Allowance">
                </div>
            </div>
        </form>
    </div>
<?php
}

if (isset($_POST['allowance_submit'])) {
    $allowance_housing = $_POST['allowance_housing'];
    $allowance_transport = $_POST['allowance_transport'];
    $allowance_lunch = $_POST['allowance_lunch'];
    $allowance_medical = $_POST['allowance_medical'];

    include '../include/conn.php';

    $sql = "INSERT INTO org_allowance(org_id, housing, transport, lunch, medical) VALUES (?, ?, ?, ?, ?)";
    $insertStatement = mysqli_prepare($conn, $sql);
    if ($insertStatement) {
        mysqli_stmt_bind_param($insertStatement, 'sssss', $username, $allowance_housing, $allowance_transport, $allowance_lunch, $allowance_medical);
        mysqli_stmt_execute($insertStatement);
        echo "<h4 class='text-center'>Allowance Added Successfully!</h4>";
        mysqli_stmt_close($insertStatement);
    } else {
        echo "<h4 class='text-center'>Error Adding Allowance!</h4>";
    }
    mysqli_close($conn);
}

if (isset($_POST['allowance_del']) || isset($_POST['allowance_delete_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Delete Allowance</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-4 form-group">
                    <select class="form-control" name="allowance">
                        <option value="">-- Select Allowance to Delete --</option>
                        <?php
                        include '../include/conn.php';
                        $search = "SELECT * FROM org_allowance WHERE org_id = ?";
                        $searchStatement = mysqli_prepare($conn, $search);
                        if ($searchStatement) {
                            mysqli_stmt_bind_param($searchStatement, 's', $username);
                            mysqli_stmt_execute($searchStatement);
                            $result = mysqli_stmt_get_result($searchStatement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $allowance_housing = $row['housing'];
                                $allowance_transport = $row['transport'];
                                $allowance_lunch = $row['lunch'];
                                $allowance_medical = $row['medical'];
                                ?>
                                <option value="<?php echo $username; ?>">
                                    <?php echo $count . ". HOUSING: " . $allowance_housing . " TRANSPORT: " . $allowance_transport . " LUNCH: " . $allowance_lunch . " MEDICAL: " . $allowance_medical; ?>
                                </option>
                                <?php
                            }
                            mysqli_stmt_close($searchStatement);
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="allowance_delete_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
<?php
}

if (isset($_POST['allowance_delete_submit'])) {
    $delete = $_POST['allowance'];
    include '../include/conn.php';
    $sql = "DELETE FROM org_allowance WHERE org_id = ?";
    $deleteStatement = mysqli_prepare($conn, $sql);
    if ($deleteStatement) {
        mysqli_stmt_bind_param($deleteStatement, 's', $username);
        mysqli_stmt_execute($deleteStatement);
        echo "<h4 class='text-center'>Allowance Deleted Successfully!</h4>";
        mysqli_stmt_close($deleteStatement);
    } else {
        echo "<h4 class='text-center'>Error Deleting Allowance!</h4>";
    }
    mysqli_close($conn);
}

if (isset($_POST['allowance_edit']) || isset($_POST['allowance_edit_submit']) || isset($_POST['update_allowance_submit'])) {
?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Edit Allowance</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-4 form-group">
                    <select class="form-control" name="allowance">
                        <option value="">-- Select Allowance to Edit --</option>
                        <?php
                        include '../include/conn.php';
                        $search = "SELECT * FROM org_allowance WHERE org_id = ?";
                        $searchStatement = mysqli_prepare($conn, $search);
                        if ($searchStatement) {
                            mysqli_stmt_bind_param($searchStatement, 's', $username);
                            mysqli_stmt_execute($searchStatement);
                            $result = mysqli_stmt_get_result($searchStatement);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $allowance_housing = $row['housing'];
                                $allowance_transport = $row['transport'];
                                $allowance_lunch = $row['lunch'];
                                $allowance_medical = $row['medical'];
                                ?>
                                <option value="<?php echo $username; ?>">
                                    <?php echo $count . ". HOUSING: " . $allowance_housing . " TRANSPORT: " . $allowance_transport . " LUNCH: " . $allowance_lunch . " MEDICAL: " . $allowance_medical; ?>
                                </option>
                                <?php
                            }
                            mysqli_stmt_close($searchStatement);
                        }
                        mysqli_close($conn);
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="allowance_edit_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
<?php
}

if (isset($_POST['allowance_edit_submit']) || isset($_POST['update_allowance_submit'])) {
    @$allowance = $_POST['allowance'];

    include '../include/conn.php';

    $sql = "SELECT * FROM org_allowance WHERE org_id = ?";
    $selectStatement = mysqli_prepare($conn, $sql);
    if ($selectStatement) {
        mysqli_stmt_bind_param($selectStatement, 's', $username);
        mysqli_stmt_execute($selectStatement);
        $result = mysqli_stmt_get_result($selectStatement);
        $row = mysqli_fetch_assoc($result);
        @$allowance_housing = $row['housing'];
        @$allowance_transport = $row['transport'];
        @$allowance_lunch = $row['lunch'];
        @$allowance_medical = $row['medical'];
?>
    <div class="col-sm-12">
        <h4>Update Allowance Rate</h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <label>Housing Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_housing" value="<?php echo $allowance_housing; ?>">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Transport Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_transport" value="<?php echo $allowance_transport; ?>">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Lunch Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_lunch" value="<?php echo $allowance_lunch; ?>">
                </div>
                <div class="col-sm-3 form-group">
                    <label>Medical Allowance Rate(%)</label>
                    <input type="text" class="form-control" name="allowance_medical" value="<?php echo $allowance_medical; ?>">
                </div>
                <div class="col-sm-3 form-group">
                    <input type="submit" class="form-control approve" name="update_allowance_submit" value="Update Allowance">
                </div>
            </div>
        </form>
    </div>
<?php
        mysqli_stmt_close($selectStatement);
    } else {
        echo "<h4 class='text-center'>Error Retrieving Allowance Data!</h4>";
    }
    mysqli_close($conn);
}

if (isset($_POST['update_allowance_submit'])) {
    $allowance_housing = $_POST['allowance_housing'];
    $allowance_transport = $_POST['allowance_transport'];
    $allowance_lunch = $_POST['allowance_lunch'];
    $allowance_medical = $_POST['allowance_medical'];

    include '../include/conn.php';

    $sql = "UPDATE org_allowance SET housing = ?, transport = ?, lunch = ?, medical = ? WHERE org_id = ?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if ($updateStatement) {
        mysqli_stmt_bind_param($updateStatement, 'sssss', $allowance_housing, $allowance_transport, $allowance_lunch, $allowance_medical, $username);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center'>Update Successful!</h4>";
        mysqli_stmt_close($updateStatement);
    } else {
        echo "<h4 class='text-center'>Error Updating Allowance!</h4>";
    }
    mysqli_close($conn);
}
?>

<?php /*
	if(isset($_POST['allowance_add']) || isset($_POST['allowance_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Add Allowance</i></h4>
			<br>
		</div>
			<div class="col-sm-12">
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-3 form-group">
							<label>Housing Allowance Rate(%)</label>
							<input type="text" class="form-control" name="allowance_housing" placeholder="Allowance Name Rate(%)...">
						</div>
						<div class="col-sm-3 form-group">
							<label>Transport Allowance Rate(%)</label>
							<input type="text" class="form-control" name="allowance_transport" placeholder="Allowance Code Rate(%)...">
						</div>
						<div class="col-sm-3 form-group">
							<label>Lunch Allowance Rate(%)</label>
							<input type="text" class="form-control" name="allowance_lunch" placeholder="Allowance Lunch Rate(%)...">
						</div>
						<div class="col-sm-3 form-group">
							<label>Medical Allowance Rate(%)</label>
							<input type="text" class="form-control" name="allowance_medical" placeholder="Allowance Medical Rate(%)...">
						</div>
						<div class="col-sm-3 form-group">
							<input type="submit" class="form-control approve" name="allowance_submit" value="Add Allowance">
						</div>
					</div>
				</form>
			</div>
	<?php
	}
	if(isset($_POST['allowance_submit'])){
		$allowance_housing = $_POST['allowance_housing'];
		$allowance_transport = $_POST['allowance_transport'];
		$allowance_lunch = $_POST['allowance_lunch'];
		$allowance_medical = $_POST['allowance_medical'];
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO org_allowance(org_id,housing,transport,lunch,medical)VALUES(?,?,?,?,?)";
		$insertStatment = mysqli_prepare($conn,$sql);
		if(!$insertStatment){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatment,'sssss',$username,$allowance_housing,$allowance_transport,$allowance_lunch,$allowance_medical);
			mysqli_stmt_execute($insertStatment);
			echo "<h4 class='text-center'>Allowance Added Successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['allowance_del']) || isset($_POST['allowance_delete_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Delete Allowance</i></h4>
			<br>
		</div>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-4 form-group">
						<select class="form-control" name="allowance">
							<option value="">-- Select Allowance to Delete --</option>
							<?php
								include '../include/conn.php';
								$search = "SELECT * FROM org_allowance WHERE org_id = ?";
								$searchStatement = mysqli_prepare($conn,$search);
								if(!$searchStatement){
									echo "";
								}else{
									mysqli_stmt_bind_param($searchStatement,'s',$username);
									mysqli_stmt_execute($searchStatement);
									$result = mysqli_stmt_get_result($searchStatement);
									$count = 0;
									while($row = mysqli_fetch_assoc($result)){
										$count = $count + 1;
										$allowance_housing = $row['housing'];
										$allowance_transport = $row['transport'];
										$allowance_lunch = $row['lunch'];
										$allowance_medical = $row['medical'];
										?>
											<option value="<?php echo $username;?>"><?php echo $count.". HOUSING: ".$allowance_housing." TRANSPORT: ".$allowance_transport." LUNCH: ".$allowance_lunch." MEDICAL: ".$allowance_medical;?></option>
										<?php
									}
								}
							?>
						</select>
					</div>
					<div class="col-sm-3 form-group">
						<input type="submit" class="form-control approve" name="allowance_delete_submit" value="Submit">
					</div>
				</div>
			</form>
		</div>
	</div>
	<?php
	}
	if(isset($_POST['allowance_delete_submit'])){
		$delete = $_POST['allowance'];
		include '../include/conn.php';
		$sql = "DELETE FROM org_allowance WHERE org_id = ?";
		$deleteStatement = mysqli_prepare($conn,$sql);
		if(!$deleteStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($deleteStatement,'ss',$username,$delete);
			mysqli_stmt_execute($deleteStatement);
			echo "<h4 class='text-center'>Allowance deleted successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['allowance_edit']) || isset($_POST['allowance_edit_submit']) || isset($_POST['update_allowance_submit'])){
		?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Edit Allowance</i></h4>
			<br>
		</div>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-4 form-group">
						<select class="form-control" name="allowance">
							<option value="">-- Select Allowance to Edit --</option>
							<?php
								include '../include/conn.php';
								$search = "SELECT * FROM org_allowance WHERE org_id = ?";
								$searchStatement = mysqli_prepare($conn,$search);
								if(!$searchStatement){
									echo "";
								}else{
									mysqli_stmt_bind_param($searchStatement,'s',$username);
									mysqli_stmt_execute($searchStatement);
									$result = mysqli_stmt_get_result($searchStatement);
									$count = 0;
									while($row = mysqli_fetch_assoc($result)){
										$count = $count + 1;
										$allowance_housing = $row['housing'];
										$allowance_transport = $row['transport'];
										$allowance_lunch = $row['lunch'];
										$allowance_medical = $row['medical'];
										?>
											<option value="<?php echo $username;?>"><?php echo $count.". HOUSING: ".$allowance_housing." TRANSPORT: ".$allowance_transport." LUNCH: ".$allowance_lunch." MEDICAL: ".$allowance_medical;?></option>
										<?php
									}
								}
							?>
						</select>
					</div>
					<div class="col-sm-3 form-group">
						<input type="submit" class="form-control approve" name="allowance_edit_submit" value="Submit">
					</div>
				</div>
			</form>
		</div>
<?php
	}
	if(isset($_POST['allowance_edit_submit']) || isset($_POST['update_allowance_submit'])){
		@$allowance = $_POST['allowance'];
		
		include '../include/conn.php';
		
		$sql = "SELECT * FROM org_allowance WHERE org_id = ?";
		$selectStatement = mysqli_prepare($conn,$sql);
		if(!$selectStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($selectStatement,'s',$username);
			mysqli_stmt_execute($selectStatement);
			$result = mysqli_stmt_get_result($selectStatement);
			$row = mysqli_fetch_assoc($result);
			@$allowance_housing = $row['housing'];
			@$allowance_transport = $row['transport'];
			@$allowance_lunch = $row['lunch'];
			@$allowance_medical = $row['medical'];
		
		?>
		<div class="col-sm-12">
			<h4>Update Allowance Rate</h4>
			<br>
		</div>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-3 form-group">
						<label>Housing Allowance Rate(%)</label>
						<input type="text" class="form-control" name="allowance_housing" value="<?php echo $allowance_housing;?>">
					</div>
					<div class="col-sm-3 form-group">
						<label>Transport Allowance Rate(%)</label>
						<input type="text" class="form-control" name="allowance_transport" value="<?php echo $allowance_transport;?>">
					</div>
					<div class="col-sm-3 form-group">
						<label>Lunch Allowance Rate(%)</label>
						<input type="text" class="form-control" name="allowance_lunch" value="<?php echo $allowance_lunch;?>">
					</div>
					<div class="col-sm-3 form-group">
						<label>Medical Allowance Rate(%)</label>
						<input type="text" class="form-control" name="allowance_medical" value="<?php echo $allowance_medical;?>">
					</div>
					<div class="col-sm-3 form-group">
						<input type="submit" class="form-control approve" name="update_allowance_submit" value="Update Allowance">
					</div>
				</div>
			</form>
		</div>
<?php
		}
	}
	if(isset($_POST['update_allowance_submit'])){
		$allowance_housing = $_POST['allowance_housing'];
		$allowance_transport = $_POST['allowance_transport'];
		$allowance_lunch = $_POST['allowance_lunch'];
		$allowance_medical = $_POST['allowance_medical'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE org_allowance SET housing = ?, transport = ?, lunch = ?, medical = ? WHERE org_id = ?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'sssss',$allowance_housing,$allowance_transport,$allowance_lunch,$allowance_medical,$username);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 clas='text-center'>Update Successful!</h4>";
			mysqli_close($conn);
		}
	}*/
?>
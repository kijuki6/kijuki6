<?php
	if(isset($_POST['stat_deduction_submit'])){
		$country = $_POST['country'];
		$health = $_POST['stat_health'];
		$health_name = $_POST['health_name'];
		$pension = $_POST['stat_pension'];
		$pension_name = $_POST['pension_name'];
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO tax_management(org_id,country,health,health_name,pension,pension_name)VALUES(?,?,?,?,?,?)";
		$insertStatement = mysqli_prepare($conn,$sql);
		if(!$insertStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatement,'ssssss',$username,$country,$health,$health_name,$pension,$pension_name);
			mysqli_stmt_execute($insertStatement);
			echo "<h4 class='text-center'>Added Statutory Deduction Successfully!</h4>";
			mysqli_close($conn);
		}
	}
?>
<?php
	if(isset($_POST['update_stat_deduction_submit'])){
		$stat_health = $_POST['stat_health'];
		$health_name = $_POST['health_name'];
		$stat_pension = $_POST['stat_pension'];
		$pension_name = $_POST['pension_name'];
		
		include '../include/conn.php';
		
		$sql = "UPDATE tax_management SET health = ?, health_name = ?, pension = ?, pension_name = ? WHERE org_id = ?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'sssss',$stat_health,$health_name,$stat_pension,$pension_name,$username);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 class='text-center'>Updated Successfully</h4>";
			
		}
		
	}
?>
<?php
if (isset($_POST['delete_employee'])){
    $employee_id = htmlspecialchars($_POST['employee_id']);

    // Include database connection
    include '../include/conn.php';

    // Check if the employee exists
    $sql_del = "SELECT * FROM org_emp_management WHERE org_id = ? AND employee_id = ?";
    $log_data = mysqli_prepare($conn,$sql_del);
    if($log_data){
        mysqli_stmt_bind_param($log_data,'ss',$username,$employee_id);
        mysqli_stmt_execute($log_data);
        $result = mysqli_stmt_get_result($log_data);
        $row = mysqli_fetch_assoc($result);
        
        if($row){
            $org_id = $row['org_id'];
            $fname = $row['fname'];
            $lname = $row['lname'];
            $oname = $row['oname'];
            $employee_id = $row['employee_id'];
            $phone = $row['phone'];
            $dob = $row['dob'];
            $email = $row['email'];
            $address = $row['address'];
            $user_id = md5($employee_id); // Ensure user_id is correctly defined

            // Log directory and file creation
            $log_dir = "../admin/logs/employee_management/".$organisation_name."_".$org_tpin."/delete_employee/";
            if(!file_exists($log_dir)){
                mkdir($log_dir,0777,true);
            }
            $log_file = $log_dir."delete_employee.txt";
            // Check if the log file is empty and add column headings
            if(!file_exists($log_file)||filesize($log_file) === 0){
                file_put_contents($log_file,sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", "Date/Time", "Full Name", "ID#", "Phone#", "DOB", "Email Address", "Home Address"), FILE_APPEND);
            }
            // Append employee data to the log file
            $date = date("Y-m-d H:i:s");
            file_put_contents($log_file,sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n",$date,$fname." ".$lname,$employee_id,$phone,$dob,$email,$address), FILE_APPEND);
            
            // Delete the employee from the database
            $sql = "DELETE FROM org_emp_management WHERE employee_id = ?";
            $deleteStatement = mysqli_prepare($conn,$sql);
            if($deleteStatement){
                mysqli_stmt_bind_param($deleteStatement,'s',$employee_id);
                mysqli_stmt_execute($deleteStatement);
                echo "<h4 class='text-center' style='color: #ff0000;'>Employee Successfully Deleted!</h4>";
            }else{
                echo "<h4 class='text-center' style='color: #ff0000;'>Error: Could not prepare delete statement.</h4>";
            }
        }else{
            echo "<h4 class='text-center' style='color: #ff0000;'>Error: Employee not found.</h4>";
        }
        mysqli_close($conn);
    }else{
        echo "<h4 class='text-center' style='color: #ff0000;'>Error: Could not prepare select statement.</h4>";
    }
}
?>

<?php
	

// Check if session variable is set
if (!isset($_SESSION['username'])) {
    die("Access denied: No user session found.");
}

include '../include/conn.php';

if (isset($_POST['salary_manage']) || isset($_POST['salary_manage_submit'])) {
    ?>
    <div class="col-sm-12">
        <h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Salary/Employee Management</i></h4>
        <br>
    </div>
    <div class="col-sm-12">
        <form action="" method="POST">
            <div class="row">
                <div class="col-sm-3 form-group">
                    <label>Employee Name</label>
                    <select name="employee_id" class="form-control">
                        <option value="">-- Select Employee --</option>
                        <?php
                        $sql_employees = "SELECT * FROM org_emp_management WHERE org_id = ?";
                        $read_employees = mysqli_prepare($conn, $sql_employees);
                        if ($read_employees) {
                            mysqli_stmt_bind_param($read_employees, 's', $username);
                            mysqli_stmt_execute($read_employees);
                            $result = mysqli_stmt_get_result($read_employees);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $fname = htmlspecialchars($row['fname']);
                                $lname = htmlspecialchars($row['lname']);
                                $oname = htmlspecialchars($row['oname']);
                                $employee_id = htmlspecialchars($row['employee_id']);
                                ?>
                                <option value="<?php echo $employee_id; ?>"><?php echo "$count. $fname $lname $oname $employee_id"; ?></option>
                                <?php
                            }
                            mysqli_stmt_close($read_employees);
                        }
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <label>Department Name</label>
                    <select name="department" class="form-control">
                        <option value="">-- Select Department --</option>
                        <?php
                        $sql_department = "SELECT * FROM org_department WHERE org_id = ?";
                        $read_department = mysqli_prepare($conn, $sql_department);
                        if ($read_department) {
                            mysqli_stmt_bind_param($read_department, 's', $username);
                            mysqli_stmt_execute($read_department);
                            $result = mysqli_stmt_get_result($read_department);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $department_name = htmlspecialchars($row['department_name']);
                                $department_code = htmlspecialchars($row['department_code']);
                                ?>
                                <option value="<?php echo $department_code; ?>"><?php echo "$count. $department_name"; ?></option>
                                <?php
                            }
                            mysqli_stmt_close($read_department);
                        }
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <label>Position Name</label>
                    <select name="position" class="form-control">
                        <option value="">-- Select Position --</option>
                        <?php
                        $sql_position = "SELECT * FROM org_position WHERE org_id = ?";
                        $read_position = mysqli_prepare($conn, $sql_position);
                        if ($read_position) {
                            mysqli_stmt_bind_param($read_position, 's', $username);
                            mysqli_stmt_execute($read_position);
                            $result = mysqli_stmt_get_result($read_position);
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $count++;
                                $position_name = htmlspecialchars($row['position_name']);
                                $position_code = htmlspecialchars($row['position_code']);
                                ?>
                                <option value="<?php echo $position_code; ?>"><?php echo "$count. $position_name $position_code"; ?></option>
                                <?php
                            }
                            mysqli_stmt_close($read_position);
                        }
                        ?>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <label>Salary Type</label>
                    <select class="form-control" name="salary_type" required>
                        <option value="">-- Select Salary Type --</option>
                        <option value="fixed">1. Fixed</option>
                        <option value="hourly">2. Hourly</option>
                    </select>
                </div>
                <div class="col-sm-3 form-group">
                    <label></label>
                    <input type="submit" class="form-control approve" name="salary_manage_submit" value="Submit">
                </div>
            </div>
        </form>
    </div>
    <?php
}

if (isset($_POST['salary_type_submit'])) {
    $salary_name = $_POST['salary_name'];
    $tax_band = $_POST['tax_band'];

    $sql = "INSERT INTO salary_type(org_id, salary_type) VALUES (?, ?)";
    $insertStatement = mysqli_prepare($conn, $sql);
    if ($insertStatement) {
        mysqli_stmt_bind_param($insertStatement, 'ss', $username, $salary_name);
        mysqli_stmt_execute($insertStatement);
        echo "<h4 class='text-center'>Tax type added successfully!</h4>";
        mysqli_stmt_close($insertStatement);
    }
}

if (isset($_POST['salary_manage_submit'])) {
    $employee_id = $_POST['employee_id'];
    $department = $_POST['department'];
    $position = $_POST['position'];
    $salary_type = $_POST['salary_type'];

    $sql = "INSERT INTO org_salary_management(org_id, employee_id, department, position, salary_type) VALUES (?, ?, ?, ?, ?)";
    $insertStatement = mysqli_prepare($conn, $sql);
    if ($insertStatement) {
        mysqli_stmt_bind_param($insertStatement, 'sssss', $username, $employee_id, $department, $position, $salary_type);
        mysqli_stmt_execute($insertStatement);
        mysqli_stmt_close($insertStatement);

        if ($salary_type == 'fixed') {
            ?>
            <div class="row">
                <div class="col-sm-12">
                    <hr>
                    <p style="font-size: 1.5em; color: #b3b3b3;">Enter fixed salary amount for:</p><p><b><?php echo htmlspecialchars($employee_id); ?></b></p>
                    <br>
                </div>
                <div class="col-sm-12">
                    <form action="" method="POST">
                        <div class="col-sm-3 form-group">
                            <label for="fixed_salary">Enter Fixed Salary Amount</label>
                            <input type="number" class="form-control" id="fixed_salary" name="fixed_salary" placeholder="Enter Salary Amount..." required>
                            <input type="hidden" class="form-control" name="fixed_id" value="<?php echo htmlspecialchars($employee_id); ?>">
                        </div>
                        <div class="col-sm-3 form-group">
                            <label></label>
                            <input type="submit" class="form-control approve" name="fixed_salary_submit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
            <?php
        } elseif ($salary_type == 'hourly') {
            ?>
            <div class="row">
                <div class="col-sm-12">
                    <hr>
                    <p style="font-size: 1.5em; color: #b3b3b3;">Enter hourly salary rate for:</p><p><b><?php echo htmlspecialchars($employee_id); ?></b></p>
                    <br>
                </div>
                <div class="col-sm-12">
                    <form action="" method="POST">
                        <div class="col-sm-3 form-group">
                            <label for="hourly_salary">Enter Hourly Salary Rate</label>
                            <input type="number" class="form-control" id="hourly_salary" name="hourly_salary" placeholder="Enter Hourly Rate..." required>
                            <input type="hidden" class="form-control" name="hourly_id" value="<?php echo htmlspecialchars($employee_id); ?>">
                        </div>
                        <div class="col-sm-3 form-group">
                            <label></label>
                            <input type="submit" class="form-control approve" name="hourly_salary_submit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
            <?php
        }
    }
}

if (isset($_POST['fixed_salary_submit'])) {
    $fixed_salary = $_POST['fixed_salary'];
    $employee_id = $_POST['fixed_id'];

    $sql = "UPDATE org_salary_management SET s_fixed = ? WHERE employee_id = ? AND org_id = ?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if ($updateStatement) {
        mysqli_stmt_bind_param($updateStatement, 'sss', $fixed_salary, $employee_id, $username);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center'>Employee/Salary Matched successfully!</h4>";
        mysqli_stmt_close($updateStatement);
    }
}

if (isset($_POST['hourly_salary_submit'])) {
    $hourly_salary = $_POST['hourly_salary'];
    $employee_id = $_POST['hourly_id'];

    $sql = "UPDATE org_salary_management SET s_hourly = ? WHERE employee_id = ? AND org_id = ?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if ($updateStatement) {
        mysqli_stmt_bind_param($updateStatement, 'sss', $hourly_salary, $employee_id, $username);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center'>Employee/Salary Matched successfully!</h4>";
        mysqli_stmt_close($updateStatement);
    }
}

mysqli_close($conn);
?>
<?php
	/*if(isset($_POST['salary_manage']) || isset($_POST['salary_manage_submit'])){
		include '../include/conn.php';
		?>
			<div class="col-sm-12">
				<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Salary/Employee Management</i></h4>
				<br>
			</div>
				<div class="col-sm-12">
					<form action="" method="POST">
						<div class="row">
							<div class="col-sm-3 form-group">
								<label>Employee Name</label>
								<select name="employee_id" class="form-control">
									<option value="">-- Select Employee --</option>
									<?php
										$sql_employees = "SELECT * FROM org_emp_management WHERE org_id = ?";
										$read_employees = mysqli_prepare($conn,$sql_employees);
										if(!$read_employees){
											echo "";
										}else{
											mysqli_stmt_bind_param($read_employees,'s',$username);
											mysqli_stmt_execute($read_employees);
											$result = mysqli_stmt_get_result($read_employees);
											$count = 0;
											while($row = mysqli_fetch_assoc($result)){
												$count = $count + 1;
												$fname = $row['fname'];
												$lname = $row['lname'];
												$oname = $row['oname'];
												$employee_id = $row['employee_id'];
											?>
												<option value="<?php echo $employee_id;?>"><?php echo $count.". ".$fname." ".$lname." ".$oname." ".$employee_id;?></option>
											<?php
											}
										}
									?>
								</select>
							</div>
							<div class="col-sm-3 form-group">
								<label>Department Name</label>
								<select name="department" class="form-control">
									<option value="">-- Select Department --</option>
									<?php
										$sql_department = "SELECT * FROM org_department WHERE org_id = ?";
										$read_department = mysqli_prepare($conn,$sql_department);
										if(!$read_department){
											echo "";
										}else{
											mysqli_stmt_bind_param($read_department,'s',$username);
											mysqli_stmt_execute($read_department);
											$result = mysqli_stmt_get_result($read_department);
											$count = 0;
											while($row = mysqli_fetch_assoc($result)){
												$count = $count + 1;
												$department_name = $row['department_name'];
												$department_code = $row['department_code'];
											?>
												<option value="<?php echo $department_code;?>"><?php echo $count.". ".$department_name;?></option>
											<?php
											}
										}
									?>
								</select>
							</div>
							<div class="col-sm-3 form-group">
								<label>Position Name</label>
								<select name="position" class="form-control">
									<option value="">-- Select Position --</option>
									<?php
										$sql_position = "SELECT * FROM org_position WHERE org_id = ?";
										$read_position = mysqli_prepare($conn,$sql_position);
										if(!$read_position){
											echo "";
										}else{
											mysqli_stmt_bind_param($read_position,'s',$username);
											mysqli_stmt_execute($read_position);
											$result = mysqli_stmt_get_result($read_position);
											$count = 0;
											while($row = mysqli_fetch_assoc($result)){
												$count = $count + 1;
												$position_name = $row['position_name'];
												$position_code = $row['position_code'];
											?>
												<option value="<?php echo $position_code;?>"><?php echo $count.". ".$position_name." ".$position_code;?></option>
											<?php
											}
										}
									?>
								</select>
							</div>
							<div class="col-sm-3 form-group">
								<label>Salary Type</label>
								<select class="form-control" name="salary_type" required>
									<option value="">-- Select Salary Type --</option>
									<option value="fixed">1. Fixed</option>
									<option value="hourly">2. Hourly</option>
								</select>
							</div>
							<div class="col-sm-3 form-group">
								<label></label>
								<input type="submit" class="form-control approve" name="salary_manage_submit" value="Submit">
							</div>
						</div>
					</form>
				</div>
		<?php
	}
	if(isset($_POST['salary_type_submit'])){
		$salary_name = $_POST['salary_name'];
		$tax_band = $_POST['tax_band'];
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO salary_type(org_id,salary_type)VALUES(?,?)";
		$insertStatement = mysqli_prepare($conn,$sql);
		if(!$insertStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatement,'ss',$username,$salary_name);
			mysqli_stmt_execute($insertStatement);
			echo "<h4 class='text-center'>Tax type added successfully!</h4>";
			mysqli_close($conn);
		}
	}
	if(isset($_POST['salary_manage_submit'])){
		$employee_id = $_POST['employee_id'];
		$department = $_POST['department'];
		$position = $_POST['position'];
		$salary_type = $_POST['salary_type'];
		//$salary_amount = $_POST['salary_amount'];
		
		
		include '../include/conn.php';
		
		$sql = "INSERT INTO org_salary_management(org_id,employee_id,department,position,salary_type)VALUES(?,?,?,?,?)";
		$insertStatement = mysqli_prepare($conn,$sql);
		if(!$insertStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatement,'sssss',$username,$employee_id,$department,$position,$salary_type);
			mysqli_stmt_execute($insertStatement);
			if($salary_type == 'fixed'){
				?>
				<div class="row">
					<div class="col-sm-12">
						<hr>
						<p style="font-size: 1.5em; color: #b3b3b3;">Enter fixed salary amount for:</p><p><b><?php echo $employee_id;?></b></p>
						<br>
					</div>
					<div class="col-sm-12">
						<form action="" method="POST">
							<div class="col-sm-3 form-group">
								<label for="fixed_salary">Enter Fixed Salary Amount</label>
								<input type="number" class="form-control" id="fixed_salary" name="fixed_salary" placeholder="Enter Salary Amount..." required>
								<input type="hidden" class="form-control" name="fixed_id" value="<?php echo $employee_id;?>">
							</div>
							<div class="col-sm-3 form-group">
								<label></label>
								<input type="submit" class="form-control approve" name="fixed_salary_submit" value="Submit">
							</div>
						</form>
					</div>
				</div>
				<?php
			}elseif($salary_type == 'hourly'){
				?>
				<div class="row">
					<div class="col-sm-12">
						<hr>
						<p style="font-size: 1.5em; color: #b3b3b3;">Enter hourly salary rate for:</p><p><b><?php echo $employee_id;?></b></p>
						<br>
					</div>
					<div class="col-sm-12">
						<form action="" method="POST">
							<div class="col-sm-3 form-group">
								<label for="hourly_salary">Enter Hourly Salary Rate</label>
								<input type="number" class="form-control" id="hourly_salary" name="hourly_salary" placeholder="Enter Hourly Rate..." required>
								<input type="hidden" class="form-control" name="hourly_id" value="<?php echo $employee_id;?>">
							</div>
							<div class="col-sm-3 form-group">
								<label></label>
								<input type="submit" class="form-control approve" name="hourly_salary_submit" value="Submit">
							</div>
						</form>
					</div>
				</div>
				<?php
			}
		}
	}
	if(isset($_POST['fixed_salary_submit'])){
		$fixed_salary = $_POST['fixed_salary'];
		
		$sql = "UPDATE org_salary_management SET s_fixed = ? WHERE employee_id = ?";
				
		include '../include/conn.php';
		
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'ss',$fixed_salary,$employee_id);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 class='text-center'>Employee/Salary Matched successfully!</h4>";
			mysqli_close($conn);
		}		
	}
	
	if(isset($_POST['hourly_salary_submit'])){
		$hourly_salary = $_POST['hourly_salary'];
		
		$sql = "UPDATE org_salary_management SET s_hourly = ? WHERE employee_id = ?";
		
		include '../include/conn.php';
		
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($updateStatement,'ss',$hourly_salary,$employee_id);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 class='text-center'>Employee/Salary Matched successfully!</h4>";
			mysqli_close($conn);
		}	
	}*/
?>
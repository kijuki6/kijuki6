<?php 
	
	include '../include/conn.php';
	
	$sql = "DELETE FROM temp_table_id WHERE org_id = ?";
	$delete_statement = mysqli_prepare($conn,$sql);
	mysqli_stmt_bind_param($delete_statement,'s',$username);
	mysqli_stmt_execute($delete_statement);
	//echo "Temp Table Cleared";

	if(isset($_POST['payroll_review_employee_list']) || isset($_GET['pageno']) || isset($_POST['archive'])){
?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Payroll Review - Employee List</i></h4>
			<br>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<form method="POST" action="">
					<div class="col-sm-3 form-group">
						<select class="form-control" name="list_update">
							<option value="">-- Select Employee to Delete from Payroll --</option>
							<?php
								
								include '../include/conn.php';
								
								
								$sql = "SELECT * FROM org_emp_management WHERE org_id = ?";
								$select_emp = mysqli_prepare($conn,$sql);
								if(!$select_emp){
									echo "";
								}else{
									mysqli_stmt_bind_param($select_emp,'s',$username);
									mysqli_stmt_execute($select_emp);
									$result = mysqli_stmt_get_result($select_emp);
									$count = 0;
									while($row = mysqli_fetch_assoc($result)){
										$count = $count + 1;
										$lname = $row['lname'];
										$fname = $row['fname'];
										$oname = $row['oname'];
										$emp_id = $row['employee_id'];
									?>
										<option value="<?php echo $emp_id;?>"><?php echo $count.". ".$lname." ".$fname." ".$oname." ".$emp_id;?></option>
									<?php
									}
								}
							?>
						</select>
					</div>
					<div class="col-sm-3 form-group">
						<input type="submit" class="form-control approve" name="archive" value="Delete from Payroll">
					</div>
				</form>
				
				<?php

					// Check if session variable is set
					if (!isset($_SESSION['username'])) {
						die("Access denied: No user session found.");
					}

					$username = $_SESSION['username'];

					if (isset($_POST['archive'])) {
						$employee_id = $_POST['list_update'];

						include '../include/conn.php';

						$sql = "DELETE FROM org_emp_management WHERE org_id = ? AND employee_id = ?";
						$deleteStatement = mysqli_prepare($conn, $sql);

						if (!$deleteStatement) {
							die("Database query preparation failed: " . mysqli_error($conn));
						} else {
							mysqli_stmt_bind_param($deleteStatement, 'ss', $username, $employee_id);
							if (mysqli_stmt_execute($deleteStatement)) {
								echo "Employee successfully archived.";
							} else {
								echo "Failed to archive employee.";
							}

							// Close the statement
							mysqli_stmt_close($deleteStatement);
						}

						// Close the connection if needed
						// mysqli_close($conn);
					}
					?>

			</div>
		</div>
			<hr>
			<div class="row">
				<div class="col-sm-12">
				<style>
					table {
						width: 100%;
					}
					table tr:nth-child(odd){
						background-color: #e7e7e7;
					}
					table tr{
						border-bottom: 1px solid #fff;
					}
					table th,td {
						padding: 5px;
					}
				</style>
					<table>
						<thead>
							<tr>
								<th>#</th>
								<th>LAST NAME</th>
								<th>FIRST NAME</th>
								<th>OTHER NAME</th>
								<th>ID</th>
							</tr>
						</thead>
						<tbody>
						<?php
							
							if(isset($_GET['pageno'])){
								$pageno = $_GET['pageno'];
							}else{
								$pageno = 1;
							}
								$no_of_records_per_page = 15;
								$offset = ($pageno-1) * $no_of_records_per_page;


								$total_pages_sql = "SELECT COUNT(*) FROM org_emp_management WHERE org_id = '$username'";
								$result = mysqli_query($conn,$total_pages_sql);
								$total_rows = mysqli_fetch_array($result)[0];
								$total_pages = ceil($total_rows / $no_of_records_per_page);

								$sql = "SELECT * FROM org_emp_management WHERE org_id = '$username' LIMIT $offset, $no_of_records_per_page";
								$result = mysqli_query($conn,$sql);
							
							include '../include/conn.php';
							
							$sql_emp_list = "SELECT * FROM org_emp_management WHERE org_id = ?";
							$read_emp_list = mysqli_prepare($conn,$sql_emp_list);
							if(!$read_emp_list){
								echo "";
							}else{
								mysqli_stmt_bind_param($read_emp_list,'s',$username);
								mysqli_stmt_execute($read_emp_list);
								$result = mysqli_stmt_get_result($read_emp_list);
								$count = 0;
								while($row = mysqli_fetch_assoc($result)){
									$count = $count + 1;
									$lname = $row['lname'];
									$fname = $row['fname'];
									$oname = $row['oname'];
									$employee_id = $row['employee_id'];
								?>
									<tr>
										<td><?php echo $count;?></td>
										<td><?php echo $lname;?></td>
										<td><?php echo $fname;?></td>
										<td><?php echo $oname;?></td>
										<td><?php echo $employee_id;?></td>
									</tr>
								<?php
								}
							}
						?>
						</tbody>
					</table>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-sm-2 form-group">
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="payroll_review_employee_list" type="submit">Refresh</button>
					</form>
				</div>
				<!--<div class="col-sm-3 form-group">
					<form action="" method="POST">
						<button class="form-control approve" name="payroll_review" type="submit">Payroll Review</button>
					</form>
				</div>-->
				<div class="col-sm-2 form-group">
					<br>
					<a href="payroll_review.php"><button class="form-control approve" name="payroll_review" type="submit">Payroll Review</button></a>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<hr>
					<table>
						<thead>
							<tr>
								<td class="text-center">
									<ul class="pagination">
										<li><a href="?pageno=1">First</a></li>
										<li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
											<a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
										</li>
										<li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
											<a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
										</li>
										<li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
									</ul>
								</td>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		
<?php
	}
?>
		
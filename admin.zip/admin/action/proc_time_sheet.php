<?php
	if(isset($_POST['employee_time']) || isset($_POST['get_employee_details']) || isset($_POST['get_employee_time_details']) || isset($_POST['year_to_date'])){
?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Employee Time Sheet</i></h4>
			<br>
		</div>
		
			<div class="col-sm-12">
				<p><b>Select Employee</b></p>
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-4 form-group">
							<select name="employee" class="form-control" required>
								<option value="">-- Select Employee --</option>
								<?php
									include '../include/conn.php';
									$sql = "SELECT * FROM org_emp_management WHERE org_id = ?";
									$read = mysqli_prepare($conn,$sql);
									if(!$read){
										echo "";
									}else{
										mysqli_stmt_bind_param($read,'s',$username);
										mysqli_stmt_execute($read);
										$result = mysqli_stmt_get_result($read);
										$count = 0;
										while($row = mysqli_fetch_assoc($result)){
											$count = $count + 1;
											$id = $row['employee_id'];
											$fname = $row['fname'];
											$lname = $row['lname'];
											$oname = $row['oname'];
										?>
											<option value="<?php echo $id;?>"><?php echo $count.". ".$lname." ".$fname." ".$oname." ".$id;?></option>
										<?php
										}
									}
								?>
							</select>
						</div>
						<div class="col-sm-3">
							<input type="submit" class="form-control approve" name="get_employee_details" value="Submit">
						</div>
					</div>
				</form>
			</div>
		
	<?php
		if(isset($_POST['get_employee_details']) || isset($_POST['get_employee_time_details']) || isset($_POST['year_to_date'])){
			@$id = $_POST['employee'];
	?>
			<div class="row">
				<div class="col-sm-10">
					<p><b>Select Time Period</b></p>
					<form action="" method="POST">
						<div class="row">
							<div class="col-sm-6 form-group">
								<select name="year_month" class="form-control" required>
									<option value="">-- Select Year/Month --</option>
									<?php
										include '../include/conn.php';
										$sql = "SELECT * FROM org_time_sheet WHERE org_id = ? AND employee_id = ?";
										$read = mysqli_prepare($conn,$sql);
										if(!$read){
											echo "";
										}else{
											mysqli_stmt_bind_param($read,'ss',$username,$id);
											mysqli_stmt_execute($read);
											$result = mysqli_stmt_get_result($read);
											$count = 0;
											while($row = mysqli_fetch_assoc($result)){
												$count = $count + 1;
												$id = $row['employee_id'];
												$clock_in = $row['clock_in'];
												$clock_out = $row['clock_out'];
												$total_time = $row['total_time'];
												$date_clock = $row['date_clock'];
												$date_year = $row['date_year'];
												$date_month = $row['date_month'];
												?>
													<option value="<?php echo $id."|".$date_year."|".$date_month;?>"><?php echo $count.". ".$id." ".$date_year."/".$date_month;?></option>
												<?php
											}
										}
									?>
								</select>
							</div>
							<div class="col-sm-3">
								<input type="submit" class="form-control approve" name="get_employee_time_details" value="Submit">
							</div>
						</div>
					</form>
				</div>
				<div class="col-sm-2">
					<form action="" method="POST">
						<label>Year-to-Date</label>
						<input type="submit" class="form-control approve" name="year_to_date" value="Year-to-Date">
					</form>
				</div>
			</div>
	<?php
		}
		//Year-to-Date
		if(isset($_POST['get_employee_details'])){
			$emp_sess = $_POST['employee'];
			$_SESSION['employee'] = $emp_sess;
			
		}
		if(isset($_POST['year_to_date'])){
			$ytd_find = $_SESSION['employee'];
			$year = date('Y');
			
			include '../include/conn.php';
			
			$sql = "SELECT * FROM org_time_sheet WHERE org_id = ? AND employee_id = ? AND date_year = ?";
			$readStatement = mysqli_prepare($conn,$sql);
			if(!$readStatement){
				echo "";
			}else{
				mysqli_stmt_bind_param($readStatement,'sss',$username,$ytd_find,$year);
				mysqli_stmt_execute($readStatement);
				$result = mysqli_stmt_get_result($readStatement);
				?>
				<style>
					table {
						width: 100%;
						padding: 7px;
					}
					table tr:nth-child(odd){
						background-color: #e7e7e7;
					}
					table tr {
						border-bottom: 1px solid #fff;
					}
				</style>
				<br>
				<h4 style="font-size: 2em;">Year-to-date Time Sheet for Employee ID# <b><i>(<?php echo $ytd_find.", ".$year;?>)</i></b></h4>
				<table>
					<thead>
						<tr>
							<th>#</th>
							<th>Date</th>
							<th>Log In Time</th>
							<th>Log Out Time</th>
							<th>Total Hours</th>
							<th>Month</th>
						</tr>
					</thead>
					<tbody>
				<?php
					$count = 1;
					while($row = mysqli_fetch_assoc($result)){
						$count = $count + 1;
						$date = $row['date_clock'];
						$clock_in = $row['clock_in'];
						$clock_out = $row['clock_out'];
						$total_time = $row['total_time'];
						$month = $row['date_month'];
						?>
						<tr>
							<td><?php echo $count;?></td>
							<td><?php echo $date;?></td>
							<td><?php echo $clock_in;?></td>
							<td><?php echo $clock_out;?></td>
							<td><?php echo $total_time;?></td>
							<td><?php echo $month;?></td>
						</tr>
						<?php
					}
					?>
					</tbody>
				</table>
				<?php
			}
			
		}
		//Details
		if(isset($_POST['get_employee_time_details'])){
			$year_month = $_POST['year_month'];
			$year_month_explode = explode("|",$year_month);
			$id = $year_month_explode[0];
			$date_year = $year_month_explode[1];
			$date_month = $year_month_explode[2];
			
			include '../include/conn.php';
			
			$sql = "SELECT * FROM org_time_sheet WHERE org_id = ? AND employee_id = ? AND date_year = ? AND date_month = ?";
			$read = mysqli_prepare($conn,$sql);
			if(!$read){
				echo "";
			}else{
				mysqli_stmt_bind_param($read,'ssss',$username,$id,$date_year,$date_month);
				mysqli_stmt_execute($read);
				$result = mysqli_stmt_get_result($read);
				$count = 0;
				?>
				<style>
					table {
						width: 100%;
						padding: 7px;
					}
					table tr:nth-child(odd){
						background-color: #e7e7e7;
					}
					table tr {
						border-bottom: 1px solid #fff;
					}
				</style>
				<br>
				<h4 style="font-size: 2em;">Time Sheet for Employee ID# <b><?php echo $id." ".$date_year."/".$date_month;?></b></h4>
				<table>
					<thead>
						<tr>
							<th>#</th>
							<th>Date</th>
							<th>Log In Time</th>
							<th>Log Out Time</th>
							<th>Total Hours</th>
							<th>Hourly Rate</th>
							<th>Daily Earning</th>
						</tr>
					</thead>
					<tbody>
				<?php
				while($row = mysqli_fetch_assoc($result)){
					$count = $count + 1;
					$date_clock = $row['date_clock'];
					$clock_in = $row['clock_in'];
					$clock_out = $row['clock_out'];
					$total_time = $row['total_time'];
					$total_time = (float)$row['total_time'];
					$rate = 80;
					$daily_earning = $rate * $total_time;
					?>
					<tr>
						<td><?php echo $count;?></td>
						<td><?php echo $date_clock;?></td>
						<td><?php echo $clock_in;?></td>
						<td><?php echo $clock_out;?></td>
						<td><?php echo $total_time;?></td>
						<td><?php echo $rate;?></td>
						<td><?php echo $daily_earning;?></td>
					</tr>
					<?php
				}
				?>
					</tbody>
				</table>
				<?php
			}
		}
	}
	
	if(isset($_POST['organisation_time']) || isset($_POST['year_submit']) || isset($_POST['month_submit']) || isset($_POST['date_submit'])){
	?>
		<div class="col-sm-12">
			<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>Organisation Time Sheet</i></h4>
			<br>
		</div>
		<?php
			if(isset($_POST['organisation_time'])){
			?>
				<div class="col-sm-12">
					<form method="POST" action="">
						<div class="row">
							<div class="col-sm-4 form-group">
								<label for="year">Year</label>
								<input type="text" name="year" class="form-control" placeholder="Enter Year(YYYY)">
							</div>
							<div class="col-sm-4 form-group">
								<label for="submit"></label>
								<input type="submit" name="year_submit" class="form-control approve" value="Search">
							</div>
						</div>
					</form>
				</div>
			<?php
			}
		
			if(isset($_POST['year_submit'])){
				?>
					<div class="col-sm-12">
						<form method="POST" action="">
							<div class="row">
								<div class="col-sm-4 form-group">
									<label for="year">Month</label>
									<input type="text" name="month" class="form-control" placeholder="Enter Month(MM)">
								</div>
								<div class="col-sm-4 form-group">
									<label for="submit"></label>
									<input type="submit" name="month_submit" class="form-control approve" value="Search">
								</div>
							</div>
						</form>
					</div>
				<?php
			}
			if(isset($_POST['month_submit'])){
			?>
				<div class="col-sm-12">
					<form method="POST" action="">
						<div class="row">
							<div class="col-sm-4 form-group">
								<label for="year">Date</label>
								<input type="text" name="date" class="form-control" placeholder="Enter Year(DD)">
							</div>
							<div class="col-sm-4 form-group">
								<label for="submit"></label>
								<input type="submit" name="date_submit" class="form-control approve" value="Search">
							</div>
						</div>
					</form>
				</div>
			<?php
			}
	}
	if(isset($_POST['year_submit'])){
		$year = $_POST['year'];
		$_SESSION['got_year'] = $year;
	}
	if(isset($_POST['month_submit'])){
		$month = $_POST['month'];
		$_SESSION['got_month'] = $month;
	}
	if(isset($_POST['date_submit'])){
		$s_year = $_SESSION['got_year'];
		$s_month = $_SESSION['got_month'];
		$date = $_POST['date'];
		include '../include/conn.php';
		$find_date = $s_year."-".$s_month."-".$date;
		$sql = "SELECT * FROM org_time_sheet WHERE date_year = ? AND date_month = ? AND date_clock = ?";
		$search = mysqli_prepare($conn,$sql);
		if(!$search){
			echo '';
		}else{
			mysqli_stmt_bind_param($search,'sss',$s_year,$s_month,$find_date);
			mysqli_stmt_execute($search);
			$result = mysqli_stmt_get_result($search);
			$count = 0;
			?>
			<style>
					table {
						width: 100%;
						padding: 7px;
					}
					table tr:nth-child(odd){
						background-color: #e7e7e7;
					}
					table tr {
						border-bottom: 1px solid #fff;
					}
				</style>
				<br>
				<h4 style="font-size: 2em;">Time Sheet for <b><?php echo $s_year."/".$s_month."/".$date;?></b></h4>
				<table>
					<thead>
						<tr>
							<th>#</th>
							<th>Employee ID</th>
							<th>Log In Time</th>
							<th>Log Out Time</th>
							<th>Total Hours</th>
							<th>Hourly Rate</th>
							<th>Daily Earning</th>
						</tr>
					</thead>
					<tbody>
						<?php
						while($row = mysqli_fetch_assoc($result)){
							$count = $count + 1;
							$id = $row['employee_id'];
							$clock_in = $row['clock_in'];
							$clock_out = $row['clock_out'];
							$total_hours = $row['total_time'];
							$total_time = $row['total_time'];
							$total_time = (float)$row['total_time'];
							$rate = 80;
							$daily_earning = $rate * $total_time;
							$total_daily_wages = "";
							?>
							<tr>
								<td><?php echo $count;?></td>
								<td><?php echo $id;?></td>
								<td><?php echo $clock_in;?></td>
								<td><?php echo $clock_out;?></td>
								<td><?php echo $total_hours;?></td>
								<td><?php echo $rate;?></td>
								<td><?php echo $daily_earning;?></td>
							</tr>
							<?php
						}
						?>
						<tr>
							<td colspan="2">Total Daily Wages</td>
							<td colspan="2"><?php echo $total_daily_wages;?></td>
							<td colspan="3"></td>
						</tr>
					</tbody>
				</table>
			<?php
		}
	}
?>

<?php
	ob_start();
	session_start();
	$username = $_SESSION['username'];
	if(!isset($_SESSION['username'])){
		header('Location: ../login.php');
	}else{
		include "../assets/header.php";
		include "../assets/body.php";
		include "../include/conn.php";
		include "includes/proc_dash_payroll_review.php";
		include "../assets/footer.php";
	}
?>
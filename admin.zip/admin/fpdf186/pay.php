<?php
require('fpdf.php');

// Function to generate PDF payslip
function generatePayslip($employeeName, $salary)
{
    // Initialize PDF
    $pdf = new FPDF();
    $pdf->AddPage();

    // Add content to the PDF
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Payslip', 0, 1, 'C');
    $pdf->Ln(10);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Employee Name: ' . $employeeName, 0, 1);
    $pdf->Cell(0, 10, 'Salary: $' . $salary, 0, 1);

    // Output PDF as string
    return $pdf->Output('', 'S');
}

// Function to send email with PDF payslip attachment
function sendPayslipByEmail($employeeName, $employeeEmail, $pdfData)
{
    // Email content
    $subject = 'Payslip for ' . $employeeName;
    $message = 'Please find attached your payslip.';
    $filename = 'payslip_' . $employeeName . '.pdf';

    // Headers for attachment
    $headers = "From: your_email@example.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"boundary\"\r\n";
    $headers .= "This is a multi-part message in MIME format.\r\n";

    // Base64 encode the PDF data
    $pdfData = chunk_split(base64_encode($pdfData));

    // Email body
    $body = "--boundary\r\n";
    $body .= "Content-Type: text/plain; charset=\"utf-8\"\r\n";
    $body .= "Content-Transfer-Encoding: 7bit\r\n";
    $body .= $message . "\r\n\r\n";
    $body .= "--boundary\r\n";
    $body .= "Content-Type: application/pdf; name=\"" . $filename . "\"\r\n";
    $body .= "Content-Disposition: attachment; filename=\"" . $filename . "\"\r\n";
    $body .= "Content-Transfer-Encoding: base64\r\n";
    $body .= "\r\n" . $pdfData . "\r\n";
    $body .= "--boundary--";

    // Send email
    if (mail($employeeEmail, $subject, $body, $headers)) {
        echo 'Email sent successfully to ' . $employeeEmail;
    } else {
        echo 'Error sending email to ' . $employeeEmail;
    }
}

// Example usage
$employeeName = 'John Doe';
$employeeEmail = 'john.doe@example.com';
$salary = 5000; // Example salary

$pdfData = generatePayslip($employeeName, $salary);
sendPayslipByEmail($employeeName, $employeeEmail, $pdfData);
?>

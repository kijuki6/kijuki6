<?php
ob_start();
require('fpdf.php');
include '../../include/conn.php';

session_start();

class PDF extends FPDF
{
	// Load data
function LoadData($file)
{
    // Read file lines
    $lines = file($file);
    $data = array();
    foreach($lines as $line)
        $data[] = explode(';',trim($line));
    return $data;
}
// Page header
function Header()
{
    // Logo
    $this->Image('../logo/osas_logo.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'GPPS PAYROLL SUMMARY',0,1,'C');
    $this->Cell(0,1,'',0,1,'C');
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-20);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,5,'Page '.$this->PageNo().'/{nb}',0,1,'C');
    $this->Cell(0,5,'Powered by Green Pine Technologies Limited: Green Pine Payroll Systems',0,1,'C');
}
}

$user_id = $_SESSION['organisation_id'];
$org_name = $_SESSION['organisation_name'];
$sql = "SELECT * FROM temp_table_id WHERE org_id = ?";
$read_it = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($read_it,'s',$user_id);
mysqli_stmt_execute($read_it);
$result = mysqli_stmt_get_result($read_it);
$count = 0;


// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Cell(1,0,'',0,1);
$pdf->SetFont('Times','',10);
$pdf->Cell(1);
$pdf->Cell(188,6,'GREEN PINE TECHNOLOGIES LIMITED',0,1,'C');
$pdf->Cell(188,6,'3 BATH CRESCENT PARKLANDS, KITWE, ZAMBIA.',0,1,'C');
$pdf->Cell(188,6,'TPIN: '.$user_id,0,1,'C');
$pdf->Cell(100,2,'',0,1,'C');
$pdf->Cell(94,7,'EMAIL: accounts@greenpinetech.co.zm',0,0,'C');
$pdf->Cell(94,7,'PHONE: +260 969 596 109',0,1,'C');
$pdf->Cell(190,1,'',1,1,'C');
$pdf->Cell(100,10,'',0,1,'C');


$pdf->SetFont('Times','B',10);
$pdf->Cell(5);

$pdf->Cell(10,5,'#',0,0,'');
$pdf->Cell(36,5,'LAST NAME',0,0,'');
$pdf->Cell(36,5,'FIRST NAME',0,0,'');
$pdf->Cell(36,5,'OTHER NAME',0,0,'');
$pdf->Cell(36,5,'ID#',0,0,'');
$pdf->Cell(36,5,'NET PAY',0,1,'');
$pdf->Cell(190,1,'',0,1,'');
$pdf->Cell(190,0,'',1,1,'');
$pdf->Cell(190,1,'',0,1,'');

$pdf->SetFont('Times','',10);
while($row = mysqli_fetch_assoc($result)){
	$employee_id = $row['employee_id'];
	$count = $count + 1;
	$lname = $row['lname'];
	$fname = $row['fname'];
	$oname = $row['oname'];
	$net_pay = $row['net_pay'];
$pdf->Cell(5);
$pdf->Cell(10,5,$count,0,0,'');
$pdf->Cell(36,5,$lname,0,0,'');
$pdf->Cell(36,5,$fname,0,0,'');
$pdf->Cell(36,5,$oname,0,0,'');
$pdf->Cell(36,5,$employee_id,0,0,'');
$pdf->Cell(36,5,$net_pay,0,1,'');
$pdf->Cell(190,1,'',0,1,'');
//$pdf->Cell(190,0,'',1,1,'');
}
//Signatures
$pdf->Cell(190,0,' ',0,1,'');
$pdf->Cell(190,10,' ',0,1,'');
$pdf->Cell(190,0,' ',1,1,'');
$pdf->Cell(190,1,' ',0,1,'');
$pdf->Cell(94,5,' APPROVED BY: ',0,0,'');

//For Payroll History - Year

include '../../include/conn.php';
$folder_name = date("Y");
$link = "<img src='../logo/in_folder.png' width='100px' height='auto' alt='Folder' title='Organisation Folder'>";
$sql = "SELECT * FROM org_folder_year_summary WHERE org_id = ? AND folder_name = ?";
$test = mysqli_prepare($conn,$sql);
$date = date("Y");
if(!$test){
	echo "";
}else{
	mysqli_stmt_bind_param($test,'ss',$user_id,$folder_name);
	mysqli_stmt_execute($test);
	$result = mysqli_stmt_get_result($test);
	$row = mysqli_fetch_assoc($result);
	@$test_value_1 = $row['org_id'];
	@$test_value_2 = $row['folder_name'];
	if($test_value_1 == $user_id && $test_value_2 == $folder_name){
		//do nothing
	}else{
		$sql = "INSERT INTO org_folder_year_summary(org_id,image_link,folder_name)VALUES(?,?,?)";
		$insertStatement = mysqli_prepare($conn,$sql);
		if(!$insertStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatement,'sss',$user_id,$link,$folder_name);
			mysqli_stmt_execute($insertStatement);
			mysqli_close($conn);
		}
	}
}

//For Payroll Summary Month
include '../../include/conn.php';
$folder_name_year = date("Y");
$folder_name_month = date("m");
$link = "<img src='../logo/in_folder.png' width='100px' height='auto' alt='Folder' title='Organisation Folder'>";
$sql = "SELECT * FROM org_folder_month_summary WHERE org_id = ?";
$test = mysqli_prepare($conn,$sql);
if(!$test){
	echo "";
	mysqli_close($conn);
}else{
	mysqli_stmt_bind_param($test,'s',$user_id);
	mysqli_stmt_execute($test);
	$result = mysqli_stmt_get_result($test);
	$row = mysqli_fetch_assoc($result);
	@$test_value_1 = $row['org_id'];
	@$test_value_2 = $row['folder_year'];
	@$test_value_3 = $row['folder_month'];
	if($test_value_1 == $user_id && $test_value_2 == $folder_name_year && $test_value_3 == $folder_name_month){
		//do nothing
	}else{
		$sql = "INSERT INTO org_folder_month_summary(org_id,folder_year,folder_month,image_link)VALUES(?,?,?,?)";
		$insertStatement = mysqli_prepare($conn,$sql);
		if(!$insertStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($insertStatement,'ssss',$user_id,$folder_name_year,$folder_name_month,$link);
			mysqli_stmt_execute($insertStatement);
			mysqli_close($conn);
		}
	}
}

//summary files
include '../../include/conn.php';
$folder_name_year = date("Y");
$folder_name_month = date("m");
$file_name = "payroll_summary_".date("D m y").".pdf";
$file_link = "documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf";
$link = "<img src='../logo/pdf.png' width='100px' height='auto' alt='Folder' title='Organisation Folder'>";	
$sql = "INSERT IGNORE INTO org_folder_file_summary(org_id,folder_year,folder_month,file_name,file_link,image_link)VALUES(?,?,?,?,?,?)";
$insertStatement = mysqli_prepare($conn,$sql);
if(!$insertStatement){
	echo mysqli_error($conn);
}else{
	mysqli_stmt_bind_param($insertStatement,'ssssss',$user_id,$folder_name_year,$folder_name_month,$file_name,$file_link,$link);
	mysqli_stmt_execute($insertStatement);
	mysqli_close($conn);
}

//Backup Files and Folders
if(!file_exists("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y"))){
	mkdir("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y"));
	if(!file_exists("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"))){
		mkdir("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"));
		$pdf->Output("F","../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
	}else{
		$pdf->Output("F","../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
	}
}else{
	if(!file_exists("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"))){
		mkdir("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"));
		$pdf->Output("F","../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
	}else{
		$pdf->Output("F","../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
	}
}

//Output to Folders
if(!file_exists("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y"))){
	mkdir("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y"));
	if(!file_exists("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"))){
		mkdir("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"));
		$pdf->Output("F","../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
		$pdf->Output('D','payroll_summary.'.date("D m y").'.pdf');
	}else{
		$pdf->Output("F","../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
		$pdf->Output('D','payroll_summary.'.date("D m y").'.pdf');
	}
}else{
	if(!file_exists("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"))){
		mkdir("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m"));
		$pdf->Output("F","../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
		$pdf->Output('D','payroll_summary.'.date("D m y").'.pdf');
	}else{
		$pdf->Output("F","../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
		$pdf->Output('D','payroll_summary.'.date("D m y").'.pdf');
	}
	
}

$myfile = fopen("../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".txt","w") or die("");
$txt = $org_name."_".date("D m y")."_Summary Payroll List\n";
fwrite($myfile,$txt);
fclose($myfile);

$myfile = fopen("../documents/backups/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".txt","w") or die("");
$txt = $org_name."_".date("D m y")."_Summary Payroll List\n";
fwrite($myfile,$txt);
fclose($myfile);

//mail backup copy to greenpinetech
	$filename = "payroll_summary_".date("D m y").".pdf";
    $path = "../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m");
    $file = $path . "/" . $filename;

    //$mailto = 'gppsbackup@zedlistings.com';
    $subject = $org_name.'_Payroll Summary';
    $message = 'Dear User, \n Attached FYI backup file.';

    $content = file_get_contents($file);
    $content = chunk_split(base64_encode($content));

    // a random hash will be necessary to send mixed content
    $separator = md5(time());

    // carriage return type (RFC)
    $eol = "\r\n";

    // main header (multipart mandatory)
    $headers = "From: name <gpps@zedlistings.com>" . $eol;
    $headers .= "MIME-Version: 1.0" . $eol;
    $headers .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"" . $eol;
    $headers .= "Content-Transfer-Encoding: 7bit" . $eol;
    $headers .= "This is a MIME encoded message." . $eol;

    // message
    $body = "--" . $separator . $eol;
    $body .= "Content-Type: text/plain; charset=\"iso-8859-1\"" . $eol;
    $body .= "Content-Transfer-Encoding: 8bit" . $eol;
    $body .= $message . $eol;

    // attachment
    $body .= "--" . $separator . $eol;
    $body .= "Content-Type: application/octet-stream; name=\"" . $filename . "\"" . $eol;
    $body .= "Content-Transfer-Encoding: base64" . $eol;
    $body .= "Content-Disposition: attachment" . $eol;
    $body .= $content . $eol;
    $body .= "--" . $separator . "--";

    //SEND Mail
    /*if (mail($mailto, $subject, $body, $headers)) {
        echo "mail send ... OK"; // or use booleans here
    } else {
        echo "mail send ... ERROR!";
        print_r( error_get_last() );
    }*/

//$pdf->Output("F","../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m")."/payroll_summary_".date("D m y").".pdf");
//$pdf->Output('D','payroll_summary.'.date("D m y").'.pdf');


?>
<?php
ob_start();
require('fpdf.php');
include '../../include/conn.php';

session_start();

class PDF extends FPDF
{
	// Load data
function LoadData($file)
{
    // Read file lines
    $lines = file($file);
    $data = array();
    foreach($lines as $line)
        $data[] = explode(';',trim($line));
    return $data;
}
// Page header
function Header()
{
    // Logo
    $this->Image('../logo/osas_logo.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'GPPS PAYSLIP',0,1,'C');
    $this->Cell(0,1,'',0,1,'C');
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-20);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,5,'Page '.$this->PageNo().'/{nb}',0,1,'C');
    $this->Cell(0,5,'Powered by Green Pine Technologies Limited: Green Pine Payroll Systems',0,1,'C');
}
}

$user_id = $_SESSION['organisation_id'];
$org_name = $_SESSION['organisation_name'];
$sql = "SELECT * FROM temp_table_id WHERE org_id = ?";
$read_it = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($read_it,'s',$user_id);
mysqli_stmt_execute($read_it);
$result = mysqli_stmt_get_result($read_it);


// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();

while($row = mysqli_fetch_assoc($result)){
	$id = $_SESSION['employee_nrc'] = $row['employee_id'];
		
$pdf->AddPage();
$pdf->Cell(1,0,'',0,1);
$pdf->SetFont('Times','',10);
$pdf->Cell(1);
$pdf->Cell(188,6,'GREEN PINE TECHNOLOGIES LIMITED',0,1,'C');
$pdf->Cell(188,6,'3 BATH CRESCENT PARKLANDS, KITWE, ZAMBIA.',0,1,'C');
$pdf->Cell(188,6,'TPIN: '.$user_id,0,1,'C');
$pdf->Cell(100,2,'',0,1,'C');
$pdf->Cell(94,7,'EMAIL: accounts@greenpinetech.co.zm',0,0,'C');
$pdf->Cell(94,7,'PHONE: +260 969 596 109',0,1,'C');
$pdf->Cell(190,1,'',1,1,'C');
$pdf->Cell(100,7,'',0,1,'C');
$pdf->SetFont('Times','',10);
$pdf->Cell(49,5,'EMPLOYEE NAME: ',0,0,'');
$pdf->Cell(45,5,'',0,0,'');
$pdf->Cell(5);
$pdf->Cell(45,5,'NRC#: ',0,0,'');
$pdf->Cell(40,5,$id,0,1,'');
$pdf->Cell(40,5,'',0,1,'');
$pdf->SetFont('Times','B',8);
$pdf->Cell(1);
$pdf->Cell(45,5,'DATE',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'['.date("d\.m\.Y").']',1,0,'');
$pdf->Cell(8,5,'',0,0,'');
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'BASIC YTD',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'BASIC YTD',1,1,'');
$pdf->Cell(1);
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'EMPLOYEE ID',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'EMPLOYEE ID',1,0,'');
$pdf->Cell(8,5,'',0,0,'');
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'DEDUCTION YTD',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'DEDUCTION',1,1,'');
$pdf->Cell(1);
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'EMPLOYEE NAME',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'EMPLOYEE NAME',1,0,'');
$pdf->Cell(8,5,'',0,0,'');
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'ALLOWANCE YTD',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'ALLOWANCE YTD',1,1,'');
$pdf->Cell(1);
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'DATE OF BIRTH',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'DATE OF BIRTH',1,0,'');
$pdf->Cell(8,5,'',0,0,'');
$pdf->SetFont('Times','B',8);
$pdf->Cell(45,5,'PAYE YTD',1,0,'');
$pdf->SetFont('Times','',8);
$pdf->Cell(45,5,'PAYE YTD',1,1,'');
$pdf->Cell(10);
$pdf->Cell(100,1,'',0,1,'C');

$pdf->SetFont('Times','',8);
$pdf->Cell(100,5,'',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(30,5,'LEAVE DAYS YTD',1,0,'C');
$pdf->Cell(10,5,'10',1,0,'C');
$pdf->Cell(2);
$pdf->Cell(38,5,'LEAVE DAYS TAKEN YTD',1,0,'C');
$pdf->Cell(10,5,'100',1,0,'C');
$pdf->Cell(8);
$pdf->Cell(20,5,'MAX DAYS',1,0,'C');
$pdf->Cell(10,5,'40',1,0,'C');
$pdf->Cell(2);
$pdf->Cell(31,5,'GROSS PAY YTD',1,0,'C');
$pdf->Cell(27,5,'250,000',1,1,'C');

//Deductions and Allowances
$pdf->SetFont('Times','',10);
$pdf->Cell(100,5,'',0,1,'C');
$pdf->Cell(1);
$pdf->SetFont('Times','B',8);
$pdf->Cell(94,5,' DEDUCTIONS',1,0,'');
$pdf->Cell(94,5,' ALLOWANCES',1,1,'');
$pdf->Cell(1);
$pdf->SetFont('Times','',8);
$pdf->Cell(60,5,' PAYE',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' BASIC PAY',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(60,5,' NAPSA',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' HOUSING',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(60,5,' NHIMA',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' TRANSPORT',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(60,5,' LOANS',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' LUNCH',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(60,5,' SALARY ADVANCE',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' MEDICAL',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(60,5,' UNION',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' OVERTIME',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(1);
$pdf->Cell(60,5,' EMPLOYEE FUND',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' ALLOWANCES',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(94,5,'',0,1,'');
$pdf->Cell(1);
$pdf->SetFont('Times','B',8);
$pdf->Cell(188,0,'',1,1,'');
$pdf->Cell(188,3,'',0,1,'');
$pdf->Cell(60,5,' TOTAL DEDUCTIONS',0,0,'');
$pdf->Cell(34,5,' K---',0,0,'C');
$pdf->Cell(60,5,' TOTAL INCOME',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');
$pdf->Cell(60,5,' ',0,0,'');
$pdf->Cell(34,5,' ',0,0,'C');
$pdf->Cell(60,5,' NET PAY',0,0,'');
$pdf->Cell(34,5,' K---',0,1,'C');

//Signatures
$pdf->Cell(94,10,' ',0,1,'');
$pdf->Cell(94,5,' APPROVED BY: WILLIAM CHISONDE',0,0,'');
$pdf->Cell(94,5,' EMPLOYEE SIGNATURE:________________________________________',0,1,'');

isset($_POST[$id]);

//TXT Files
$myfile = fopen("../documents/organisations/".$org_name."_".$user_id."/payslips/".date("Y")."/".date("m")."/payslip_collated_".date("D m y").".txt","w") or die("");
$txt = $org_name."_".date("D m y")."_Collated PaySlip Data\n";
fwrite($myfile,$txt);
fclose($myfile);

//TXT Files Backup
$myfile = fopen("../documents/backups/organisations/".$org_name."_".$user_id."/payslips/".date("Y")."/".date("m")."/payslip_collated_".date("D m y").".txt","w") or die("");
$txt = $org_name."_".date("D m y")."_Collated Payslip Data\n";
fwrite($myfile,$txt);
fclose($myfile);

//Email Payslip to individual employee
//mail backup copy to greenpinetech
	$filename = "payroll_summary_".date("D m y").".pdf";
    $path = "../documents/organisations/".$org_name."_".$user_id."/payroll_summary/".date("Y")."/".date("m");
    $file = $path . "/" . $filename;

    //$mailto = 'gppsbackup@zedlistings.com';
    $subject = $org_name.'_Payroll Summary';
    $message = 'Dear User, \n Attached FYI backup file.';

    $content = file_get_contents($file);
    $content = chunk_split(base64_encode($content));

    // a random hash will be necessary to send mixed content
    $separator = md5(time());

    // carriage return type (RFC)
    $eol = "\r\n";

    // main header (multipart mandatory)
    $headers = "From: name <gpps@zedlistings.com>" . $eol;
    $headers .= "MIME-Version: 1.0" . $eol;
    $headers .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"" . $eol;
    $headers .= "Content-Transfer-Encoding: 7bit" . $eol;
    $headers .= "This is a MIME encoded message." . $eol;

    // message
    $body = "--" . $separator . $eol;
    $body .= "Content-Type: text/plain; charset=\"iso-8859-1\"" . $eol;
    $body .= "Content-Transfer-Encoding: 8bit" . $eol;
    $body .= $message . $eol;

    // attachment
    $body .= "--" . $separator . $eol;
    $body .= "Content-Type: application/octet-stream; name=\"" . $filename . "\"" . $eol;
    $body .= "Content-Transfer-Encoding: base64" . $eol;
    $body .= "Content-Disposition: attachment" . $eol;
    $body .= $content . $eol;
    $body .= "--" . $separator . "--";

    //SEND Mail
    /*if (mail($mailto, $subject, $body, $headers)) {
        echo "mail send ... OK"; // or use booleans here
    } else {
        echo "mail send ... ERROR!";
        print_r( error_get_last() );
    }*/
}

$pdf->Output('D','');

?>
<?php
	ob_start();
	session_start();
	$username = $_SESSION['email_reset'];
	if(!isset($_SESSION['email_reset'])){
		header('Location: ../login.php');
	}else{
		include "../assets/header.php";
		include "../assets/body.php";
		include "../include/conn.php";
		include "includes/reset_password.php";
		include "../assets/footer.php";
	}
?>
<div class="col-sm-12">
	<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Edit Employee in Organisation Payroll"><i>Edit Employee</i></h4>
	<br>
</div>
	<div class="col-sm-12">
		<form action="" method="POST">
			<div class="row">
				<div class="col-sm-6 form-group">
					<select class="form-control" name="employee_id" required>
						<option value="">-- Select Employee from List --</option>
						<?php
							include '../include/conn.php';
							
							$sql = "SELECT * FROM org_emp_management WHERE org_id = ?";
							$readStatement = mysqli_prepare($conn,$sql);
							if(!$readStatement){
								echo "Cannot read values at the moment!";
							}else{
								mysqli_stmt_bind_param($readStatement,'s',$username);
								mysqli_stmt_execute($readStatement);
								$result = mysqli_stmt_get_result($readStatement);
								$count = 0;
								while($row = mysqli_fetch_assoc($result)){
									$count = $count + 1;
									$employee_fname = $row['fname'];
									$employee_lname = $row['lname'];
									$employee_oname = $row['oname'];
									$employee_id = $row['employee_id'];
								?>
									<option value="<?php echo $employee_id;?>"><?php echo $count.". ".$employee_lname." ".$employee_fname." ".$employee_oname;?></option>
								<?php
								}
							}
						?>
					</select>
				</div>
				<div class="col-sm-3 form-group">
					<input type="submit" name="select_employee" value="Select Employee" class="form-control approve">
				</div>
			</div>
		</form>
	</div>

<br>
<?php
	if(isset($_POST['select_employee']) || isset($_POST['update_employee_submit'])){
		@$employee_id = $_POST['employee_id'];
		
		include '../include/conn.php';
		
		$sql = "SELECT * FROM org_emp_management WHERE employee_id = ?";
		$readStatement = mysqli_prepare($conn,$sql);
		if(!$readStatement){
			echo "";
		}else{
			mysqli_stmt_bind_param($readStatement,'s',$employee_id);
			mysqli_stmt_execute($readStatement);
			$result = mysqli_stmt_get_result($readStatement);
			$row = mysqli_fetch_assoc($result);
			@$fname = $row['fname'];
			@$lname = $row['lname'];
			@$oname = $row['oname'];
			@$id = $row['employee_id'];
			@$phone = $row['phone'];
			@$dob = $row['dob'];
			@$email = $row['email'];
			@$address = $row['address'];
		
?>
		<div class="col-sm-12">
			<form action="" method="POST">
				<div class="row">
					<div class="col-sm-3 form-group">
						<label>First Name</label>
						<input type="text" name="add_fname" class="form-control" value="<?php echo $fname;?>" required>
					</div>
					<div class="col-sm-3 form-group">
						<label>Last Name</label>
						<input type="text" name="add_lname" class="form-control" value="<?php echo $lname;?>" required>
					</div>
					<div class="col-sm-3 form-group">
						<label>Other Name</label>
						<input type="text" name="add_oname" class="form-control" value="<?php echo $oname;?>" required>
					</div>
					<!--<div class="col-sm-3 form-group">-->
						<!--<label>Employee ID</label>-->
						<input type="hidden" name="add_id" class="form-control" value="<?php echo $id;?>" required>
					<!--</div>-->
					<div class="col-sm-3 form-group">
						<label>Phone #</label>
						<input type="text" name="add_phone" class="form-control" value="<?php echo $phone;?>" required>
					</div>
					<div class="col-sm-3 form-group">
						<label>Date of Birth</label>
						<input type="text" name="add_dob" class="form-control" value="<?php echo $dob;?>"  required>
					</div>
					<div class="col-sm-3 form-group">
						<label>Email Address</label>
						<input type="text" name="add_email" class="form-control" value="<?php echo $email;?>" required>
					</div>
					<div class="col-sm-3 form-group">
						<label>Home Address</label>
						<input type="text" name="add_address" class="form-control" value="<?php echo $address;?>" required>
					</div>
					<div class="col-sm-4 form-group">
						<input type="submit" name="update_employee_submit" class="form-control approve" value="Update Employee">
					</div>
				</div>
			</form>
		</div>

<?php
		}
	}
	/*include 'action/proc_edit_employee.php';*
	if(isset($_POST['update_employee_submit'])){
		$fname = $_POST['add_fname'];
		$lname = $_POST['add_lname'];
		$oname = $_POST['add_oname'];
		$id = $_POST['add_id'];
		$phone = $_POST['add_phone'];
		$dob = $_POST['add_dob'];
		$email = $_POST['add_email'];
		$address = $_POST['add_address'];
		
		include '../include/conn.php';
				
		$sql = "UPDATE org_emp_management SET fname=?, lname=?, oname=?, phone=?, dob=?, email=?, address=? WHERE employee_id=? AND org_id=?";
		$updateStatement = mysqli_prepare($conn,$sql);
		if(!$updateStatement){
			echo mysqli_error($conn);
		}else{
			mysqli_stmt_bind_param($updateStatement,'sssssssss',$fname,$lname,$oname,$phone,$dob,$email,$address,$id,$username);
			mysqli_stmt_execute($updateStatement);
			echo "<h4 class='text-center'>Employee Successfully Updated!</h4>";
			mysqli_close($conn);
		}
	}*/
?>
<?php
if (isset($_POST['update_employee_submit'])) {
    // Retrieve and sanitize form data
    $fname = htmlspecialchars($_POST['add_fname']);
    $lname = htmlspecialchars($_POST['add_lname']);
    $oname = htmlspecialchars($_POST['add_oname']);
    $id = htmlspecialchars($_POST['add_id']);
    $phone = htmlspecialchars($_POST['add_phone']);
    $dob = htmlspecialchars($_POST['add_dob']);
    $email = htmlspecialchars($_POST['add_email']);
    $address = htmlspecialchars($_POST['add_address']);
    $user_id = md5($id);

    // Include database connection
    include '../include/conn.php';

    // Log directory and file creation
    $log_dir = "../admin/logs/employee_management/" . $organisation_name . "_" . $org_tpin . "/edit_employee/";
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    $log_file = $log_dir . "edit_employee.txt";
    // Check if the log file is empty and add column headings
    if (!file_exists($log_file) || filesize($log_file) === 0) {
        file_put_contents($log_file, sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", "Date/Time", "Full Name", "ID#", "Phone#", "DOB", "Email Address", "Home Address"), FILE_APPEND);
    }
    // Append updated employee data to the log file
    $date = date("Y-m-d H:i:s");
    file_put_contents($log_file, sprintf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", $date, $fname . " " . $lname, $id, $phone, $dob, $email, $address), FILE_APPEND);

    // Create directories for employee data if they do not exist
    $employee_dir = "documents/organisations/" . $organisation_name . "_" . $username . "/employee_data/" . $user_id;
    if (!file_exists($employee_dir)) {
        mkdir($employee_dir, 0777, true);
    }

    // Update employee data
    $sql = "UPDATE org_emp_management SET fname=?, lname=?, oname=?, phone=?, dob=?, email=?, address=? WHERE employee_id=? AND org_id=?";
    $updateStatement = mysqli_prepare($conn, $sql);
    if (!$updateStatement) {
        echo mysqli_error($conn);
    } else {
        mysqli_stmt_bind_param($updateStatement, 'sssssssss', $fname, $lname, $oname, $phone, $dob, $email, $address, $id, $username);
        mysqli_stmt_execute($updateStatement);
        echo "<h4 class='text-center' style='color: #50c878;'>***Employee Successfully Updated!***</h4>";
        mysqli_close($conn);
    }
}
?>

	<div class="col-sm-12">
		<div class="row">
			<div class="col-sm-3 form-group">
				<form action="" method="POST">
					<button class="form-control approve" name="allowance_add" type="submit">Add Allowance</button>
				</form>
			</div>
			<div class="col-sm-3 form-group">
				<form action="" method="POST">
					<button class="form-control approve" name="allowance_edit" type="submit">Edit Allowance</button>
				</form>
			</div>
			<div class="col-sm-3 form-group">
				<form action="" method="POST">
					<button class="form-control approve" name="allowance_del" type="submit">Delete Allowance</button>
				</form>
			</div>
		</div>
	</div>
<?php
	include 'action/proc_allowance_management.php';
?>
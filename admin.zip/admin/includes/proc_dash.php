<?php
    include "../include/conn.php";
    
    // Check if session variable is set
    if (!isset($_SESSION['username'])) {
        die("Access denied: No user session found.");
    }

    $sql = "SELECT * FROM users WHERE email = ? AND password_changed = ?";
    $code_status = 1;
    $email = $_SESSION['username'];
	$organisation_name = $_SESSION['organisation_name'];
    // $organisation_name; // This variable is declared but not used

    $verify = mysqli_prepare($conn, $sql);
    if (!$verify) {
        die("Database query failed: " . mysqli_error($conn));
    } else {
        mysqli_stmt_bind_param($verify, 'si', $email, $code_status); // Use 'si' for string and integer
        mysqli_stmt_execute($verify);
        $result = mysqli_stmt_get_result($verify);

        if ($result) {
            $row = mysqli_fetch_assoc($result);
            @$num_check = $row['password_changed'];

            if ($num_check == $code_status) {
                header('Location: password_change.php');
                exit(); // Ensure no further code is executed after the redirect
            } else {
                //echo "Password change not required.";
            }
        } else {
            echo "Query execution failed.";
        }
    }
?>

<div class="container-fluid">
	<div class="row">
		<div class="row">
			<div class="col-sm-10 topbar">
				<h1><span class="small">Green Pine Payroll System</span> | <?php echo $organisation_name;?></h1>
			</div>
			<div class="col-sm-2 topbar topbar-button"><a href="../logout.php"><button class="logout-button">Logout</button></a></div>
			<div class="col-sm-12">
				<hr class="separator">
			</div>
		</div>
		<div class="col-sm-3 sidebar">
			<a href="dashboard.php"><button class="side-button active"><i class="fa fa-home" aria-hidden="true"></i> Dashboard</button></a>
			<a href="employee_management.php"><button class="side-button"><i class="fa fa-users" aria-hidden="true"></i> Employee Management</button></a>
			<a href="allowance_management.php"><button class="side-button"><i class="fa fa-database" aria-hidden="true"></i> Allowance Management</button></a>
			<a href="department_management.php"><button class="side-button"><i class="fa fa-list-ol" aria-hidden="true"></i> Department Management</button></a>
			<a href="position_management.php"><button class="side-button"><i class="fa fa-arrows-v" aria-hidden="true"></i> Position Management</button></a>
			<a href="salary_management.php"><button class="side-button"><i class="fa fa-gbp" aria-hidden="true"></i> Salary Management</button></a>
			<a href="charge_management.php"><button class="side-button"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Management</button></a>
			<a href="charge_sheet.php"><button class="side-button"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Sheet</button></a>
			<a href="time_attendance_management.php"><button class="side-button"><i class="fa fa-clock-o" aria-hidden="true"></i> Time &amp; Attendance Management</button></a>
			<a href="time_sheet.php"><button class="side-button"><i class="fa fa-sticky-note-o" aria-hidden="true"></i> Time Sheet</button></a>
			<a href="payroll_management.php"><button class="side-button"><i class="fa fa-usd" aria-hidden="true"></i> Payroll Management</button></a>
		</div>
		<div class="col-sm-9 dashboard">
			<div class="row">
				<div class="col-sm-4 small-box">
					<div class="box" style="background-color: #1338be; color: #fff;">
						<h4>Employees</h4>
						<p class="info" style="font-size: 2em;">
							<?php
							include "../include/conn.php";

							// Check if session variable is set
							if (!isset($_SESSION['username'])) {
								die("Access denied: No user session found.");
							}

							$username = $_SESSION['username'];

							$sql = "SELECT * FROM org_emp_management WHERE org_id = ?";
							$readStatement = mysqli_prepare($conn, $sql);
							if (!$readStatement) {
								die("Database query preparation failed: " . mysqli_error($conn));
							} else {
								mysqli_stmt_bind_param($readStatement, 's', $username);
								mysqli_stmt_execute($readStatement);
								$result = mysqli_stmt_get_result($readStatement);

								if ($result) {
									$count = mysqli_num_rows($result); // Directly get the row count

									// Close the statement
									mysqli_stmt_close($readStatement);

									echo "<b>" . $count . "</b>";
								} else {
									echo "Query execution failed.";
								}
							}

							// Close the connection if needed
							// mysqli_close($conn);
							?>

						</p>
					</div>
				</div>
				<div class="col-sm-4 small-box">
					<div class="box" style="background-color: #1BFC06;">
						<h4>Departments</h4>
						<p class="info" style="font-size: 2em;">
							<?php
							include "../include/conn.php";

							// Check if session variable is set
							if (!isset($_SESSION['username'])) {
								die("Access denied: No user session found.");
							}

							$username = $_SESSION['username'];

							$sql = "SELECT * FROM org_department WHERE org_id = ?";
							$readStatement = mysqli_prepare($conn, $sql);
							if (!$readStatement) {
								die("Database query preparation failed: " . mysqli_error($conn));
							} else {
								mysqli_stmt_bind_param($readStatement, 's', $username);
								mysqli_stmt_execute($readStatement);
								$result = mysqli_stmt_get_result($readStatement);

								if ($result) {
									$count = mysqli_num_rows($result); // Directly get the row count

									// Close the statement
									mysqli_stmt_close($readStatement);

									echo "<b>" . $count . "</b>";
								} else {
									echo "Query execution failed.";
								}
							}

							// Close the connection if needed
							// mysqli_close($conn);
							?>

						</p>
					</div>
				</div>
				<div class="col-sm-4 small-box">
					<div class="box" style="background-color: #674403; color: #fff;">
						<h4>Last Payroll Value</h4>
						<p class="info" style="font-size: 2em;"></p>
					</div>
				</div>
				<div class="col-sm-4 small-box">
					<div class="box" style="background-color: #ff0000; color: #fff;">
						<h4>Charges</h4>
						<p class="info" style="font-size: 2em;">
					</div>
				</div>
				<div class="col-sm-4 small-box">
					<div class="box" style="background-color: #FF793B; color: #fff;">
						<h4>Deductions</h4>
						<p class="info" style="font-size: 2em;"></p>
					</div>
				</div>
				<div class="col-sm-4"><b></b></div>
				<div class="col-sm-4"><b></b></div>
			</div>
		</div>
	</div>
</div>
<h3>Tax Management</h3>
<div class="row gens">
	<div class="col-sm-12">
		<div class="row">
			<div class="col-sm-3 form-group">
				<form action="" method="POST">
					<button class="form-control approve" name="tax_bands_add" type="submit">PAYE Tax Band Setup</button>
				</form>
			</div>
			<div class="col-sm-3 form-group">
				<form action="" method="POST">
					<button class="form-control approve" name="update_bands" type="submit">Update Tax Bands</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php 
	include 'action/proc_tax_management.php';
	include 'action/proc_tax_management_update.php';
?>
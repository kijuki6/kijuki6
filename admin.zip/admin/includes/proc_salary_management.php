<h3>Salary Management</h3>
	<div class="row gens">
		<div class="col-sm-12">
			<div class="row">
				<div class="col-sm-3 form-group">
					<form action="" method="POST">
						<button class="form-control approve" name="salary_manage" type="submit">Salary/Employee Management</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php
		include "action/proc_salary_management.php";
	?>
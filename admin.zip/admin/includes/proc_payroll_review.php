<div class="col-sm-12">
	<h4 style="font-size: 2em; color: #b3b3b3;"><i>Payroll Review</i></h4>
	<br>
</div>
	<?php
		if(isset($_GET['pagenos'])){
			$pagenos = $_GET['pagenos'];
		}else{
			$pagenos = 1;
		}
		$no_of_records_per_page = 15;
		$offset = ($pagenos-1) * $no_of_records_per_page;

		$total_pages_sql = "SELECT COUNT(*) FROM org_emp_management WHERE org_id = '$username'";
		$result = mysqli_query($conn,$total_pages_sql);
		$total_rows = mysqli_fetch_array($result)[0];
		$total_pages = ceil($total_rows / $no_of_records_per_page);

		$sql = "SELECT * FROM org_emp_management WHERE org_id = '$username' LIMIT $offset, $no_of_records_per_page";
		$result = mysqli_query($conn,$sql);
						
		include '../include/conn.php';?>
			<style>
				table th, td {
					padding: 10px;
				}
			</style>
			<form action="" method="POST">
			<table>
				<thead>
					<tr>
						<th style="background-color: #1a4174; color: #fff;"></th><th colspan="2" style="background-color: #1338be;"></th><th colspan="4" style="background-color: #50c878;">ALLOWANCES</th><th colspan="4" style="background-color: #ff0000;">DEDUCTIONS</th><th style="background-color: #ffd700;"></th>
					</tr>
					<tr>
						<th style="background-color: #1a4174; color: #fff;">#</th>
						<th style="background-color: #1338be; color: #fff;">EMPLOYEE#</th>
						<th style="background-color: #1338be; color: #fff;">BASIC PAY</th>
						<th style="background-color: #50c878;">HOUSING</th>
						<th style="background-color: #50c878;">TRANSPORT</th>
						<th style="background-color: #50c878;">LUNCH</th>
						<th style="background-color: #50c878;">MEDICAL</th>
						<th style="background-color: #ff0000;">PAYE</th>
						<th style="background-color: #ff0000;">CHARGES</th>
						<th style="background-color: #ff0000;">HEALTH</th>
						<th style="background-color: #ff0000;">PENSION</th>
						<th style="background-color: #ffd700;">NET PAY</th>
					</tr>
				</thead>
				<tbody>
					<?php
						
						$sql_1 = "SELECT * FROM org_emp_management WHERE org_id = ?";
						$sql_2 = "SELECT * FROM org_salary_management WHERE org_id = ?";
						$sql_3 = "SELECT * FROM org_salary_type WHERE org = ?";
						$sql_4 = "SELECT * FROM org_supa_tax WHERE org_id = ?";
						$sql_5 = "SELECT * FROM tax_management WHERE org_id = ?";
						$sql_6 = "SELECT * FROM org_allowance WHERE org = ?";
						
						
						include '../include/conn.php';
						$readStatement = mysqli_prepare($conn,$sql_1);
						if(!$readStatement){
							echo "";
						}else{
							mysqli_stmt_bind_param($readStatement,'s',$username);
							mysqli_stmt_execute($readStatement);
							$result = mysqli_stmt_get_result($readStatement);
							$count = 0;
							while($row = mysqli_fetch_assoc($result)){
								$count = $count + 1;
								$employee_id = $row['employee_id'];
								$lname = $row['lname'];
								$fname = $row['fname'];
								$oname = $row['oname'];
							?>
								<tr>
									<td style="background-color: #1a4174; color: #fff;"><?php echo $count;?></td>
									<td style="background-color: #1338be; color: #fff;"><?php echo $employee_id;?></td>
									<td>
										<?php
											$total_time = 0;
											global $total_time;
											$sql_2 = "SELECT * FROM org_salary_management WHERE org_id = ? AND employee_id = ?";
											$salary_read = mysqli_prepare($conn,$sql_2);
											global $salary;
											if(!$salary_read){
												echo "";
											}else{
												mysqli_stmt_bind_param($salary_read,'ss',$username,$employee_id);
												mysqli_stmt_execute($salary_read);
												$result_2 = mysqli_stmt_get_result($salary_read);
												$row = mysqli_fetch_assoc($result_2);
												$salary_type = $row['salary_type'];
												$s_fixed = ['s_fixed'];
												$s_hourly = ['s_hourly'];
												if($salary_type == 'fixed'){
													$salary = $s_fixed;
													echo $salary;
												}elseif($salary_type == 'hourly'){
													$salary = $s_hourly * $total_time;
													echo $salary;
												}
											}
										?>
									</td>
									<?php
											$sql_6 = "SELECT * FROM org_allowance WHERE org_id = ?";
											$allowance_read = mysqli_prepare($conn,$sql_6);
											if(!$allowance_read){
												echo "";
											}else{
												mysqli_stmt_bind_param($allowance_read,'s',$username);
												mysqli_stmt_execute($allowance_read);
												$result_6 = mysqli_stmt_get_result($allowance_read);
												$row = mysqli_fetch_assoc($result_6);
												@$housing = $row['housing'];
												@$transport = $row['transport'];
												@$lunch = $row['lunch'];
												@$medical = $row['medical'];
												$housing_allowance = ($housing * $salary)/100;
												$transport_allowance = ($transport * $salary)/100;
												$lunch_allowance = ($lunch * $salary)/100;
												$medical_allowance = ($medical * $salary)/100;
												
												$additions = $housing_allowance + $transport_allowance + $lunch_allowance + $medical_allowance;
												
												?>
												<input type="hidden" name="allowance" value="<?php echo $additions;?>">
												<td style="background-color: #50c878;"><?php echo $housing_allowance;?></td>
												<td style="background-color: #50c878;"><?php echo $transport_allowance;?></td>
												<td style="background-color: #50c878;"><?php echo $lunch_allowance;?></td>
												<td style="background-color: #50c878;"><?php echo $medical_allowance;?></td>
												
												<?php
											}
										?>
										<td style="background-color: #ff0000;">
										<?php 
											$sql_3 = "SELECT * FROM org_supa_tax";
											$band_read = mysqli_prepare($conn,$sql_3);
											if(!$band_read){
												echo '';
											}else{
												mysqli_stmt_execute($band_read);
												$result = mysqli_stmt_get_result($band_read);
												$row = mysqli_fetch_assoc($result);
												$band_1 = $row['band_1'];
												$range_1_start = $row['range_1_start'];
												$band_2 = $row['band_2'];
												$range_2_start = $row['range_2_start'];
												$band_3 = $row['band_3'];
												$range_3_start = $row['range_3_start'];
												$region = $row['region'];
												
												$new_salary = $salary + $additions;
												//$new_salary = 10000;
												
												if($new_salary <= $range_1_start){
													echo 0;
												}
												if($new_salary > $range_1_start){
													$new_salary_1 = $new_salary - $range_1_start;
													$range_diff_1 = $range_2_start - $range_1_start;
													if($new_salary_1 > $range_diff_1){
														if($new_salary > $range_2_start){
															$new_salary_2 = $new_salary - $range_2_start;
															$range_diff_2 = $range_3_start - $range_2_start;
															if($new_salary_2 > $range_diff_2){
																if($new_salary > $range_3_start){
																$new_salary_3 = $new_salary - $range_3_start;
																echo $paye = ($new_salary_3 * $band_3)/100 + ($range_diff_1 * $band_1)/100 + ($range_diff_2 * $band_2)/100;
															}
															}else{
																echo $paye = ($new_salary_2 * $band_2)/100 + ($range_diff_1 * $band_1)/100;
															}
														}
													}else{
														echo $paye = ($new_salary_1 * $band_1)/100;
													}
												}
												
											}
										?>
									</td>
									<td style="background-color: #ff0000;">
										<?php
											$charge_name = 'LCO';
											$sql_7 = "SELECT * FROM org_charge WHERE org_id = ? AND charge_code = ?";
											$charge_read = mysqli_prepare($conn,$sql_7);
											if(!$charge_read){
												echo "";
											}else{
												mysqli_stmt_bind_param($charge_read,'ss',$username,$charge_name);
												mysqli_stmt_execute($charge_read);
												$result_7 = mysqli_stmt_get_result($charge_read);
												$row = mysqli_fetch_assoc($result_7);
													$charge_amount = $row['charge_amount'];
													$sql_8 = "SELECT * FROM org_time_attendance where org_id = ?";
													$find_hours = mysqli_prepare($conn,$sql_8);
													if(!$find_hours){
														echo "";
													}else{
														mysqli_stmt_bind_param($find_hours,'s',$username);
														mysqli_stmt_execute($find_hours);
														$result_8 = mysqli_stmt_get_result($find_hours);
														$row = mysqli_fetch_assoc($result_8);
														$max_hours = $row['max_hours'];
														$sql_time = "SELECT * FROM org_time_sheet WHERE org_id = ? AND employee_id = ?";
														$difference = mysqli_prepare($conn,$sql_time);
														if(!$difference){
															echo "";
														}else{
															mysqli_stmt_bind_param($difference,'ss',$username,$employee_id);
															mysqli_stmt_execute($difference);
															$result_9 = mysqli_stmt_get_result($difference);
															$acc_charge = 0;
															
															while($row = mysqli_fetch_assoc($result_9)){
																$t_in = $row['clock_in'];
																$t_out = $row['clock_out'];
																$t_in = strtotime($t_in);
																$t_out = strtotime($t_out);
																$diff = $t_out - $t_in;
																$total_time = $total_time + $diff;
																if($diff >= $max_hours){
																	echo 0;
																}elseif($diff < $max_hours){
																	$acc_charge = $acc_charge + $charge_amount;
																	echo $acc_charge;
																}
															}
														}
													}
											}
										?>
									</td>
									<?php 
											$sql_5 = "SELECT * FROM org_supa_statutory";
											$stat_deduct_read = mysqli_prepare($conn,$sql_5);
											if(!$stat_deduct_read){
												echo "";
											}else{
												mysqli_stmt_execute($stat_deduct_read);
												$result_5 = mysqli_stmt_get_result($stat_deduct_read);
												$row = mysqli_fetch_assoc($result_5);
												$health = $row['health'];
												$pension = $row['pension'];
												$health_deduction = ($salary * $health)/100;
												$pension_deduction = ($new_salary * $pension)/100;
												$deductions = $health_deduction + $pension_deduction;
												?>
												<input type="hidden" name="deductions" value="<?php echo $deductions;?>">
												<td style="background-color: #ff0000;"><?php echo $health_deduction?></td>
												<td style="background-color: #ff0000;"><?php echo $pension_deduction?></td>
												<?php
											}
									?>
									<td style="background-color: #ffd700;">
										<?php 
											$basic_pay = $salary;
											$gross_pay = $basic_pay + $housing_allowance + $transport_allowance + $lunch_allowance + $medical_allowance;
											//PAYE CALCULATION
											
											$total_deduction = $health_deduction + $pension_deduction + @$paye;
											$total_allowance = $housing_allowance + $transport_allowance + $lunch_allowance + $medical_allowance;
											$net_pay = $gross_pay - $total_deduction;
											echo $net_pay;
										?>
									</td>
								</tr>
							<?php
							}
						}
					?>					
				</tbody>
			</table>
				<br>
				<div class="row">
					<div class="col-sm-12">
						<hr>
						<table>
							<thead>
								<tr>
									<td class="text-center">
										<ul class="pagination">
											<li><a href="?pagenos=1">First</a></li>
											<li class="<?php if($pagenos <= 1){ echo 'disabled'; } ?>">
												<a href="<?php if($pagenos <= 1){ echo '#'; } else { echo "?pagenos=".($pagenos - 1); } ?>">Prev</a>
											</li>
											<li class="<?php if($pagenos >= $total_pages){ echo 'disabled'; } ?>">
												<a href="<?php if($pagenos >= $total_pages){ echo '#'; } else { echo "?pagenos=".($pagenos + 1); } ?>">Next</a>
											</li>
											<li><a href="?pagenos=<?php echo $total_pages; ?>">Last</a></li>
										</ul>
									</td>
								</tr>
							</thead>
						</table>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
					</div>
					<div class="col-sm-12">
						<form action="" method="POST" align="center">
							<input type="hidden" name="sess_id" value="<?php echo $username;?>">
							<div class="row">
								<div class="form-group col-sm-2">
								</div>
								<div class="form-group col-sm-3">
									<button type="submit" class="form-control approve" name="payroll_approve">Run Payroll</button>
								</div>
								<div class="form-group col-sm-3">
									<!--<button type="submit" class="form-control approve" name="payroll_summary">Payroll Summary</button>-->
									<button type="submit" class="btn approve" name="payroll_summary" style="width:100%">
										<i class="fa fa-download"></i> Payroll Summary Download
									</button>
								</div>
								<div class="form-group col-sm-3">
									<!--<button type="submit" class="form-control approve" name="payroll_collate">Payslip Collate</button>-->
									<button type="submit" class="btn approve" name="payroll_collate" style="width:100%">
										<i class="fa fa-download"></i> Collated Payslip Download
									</button>
								</div>
								<div class="form-group col-sm-1">
								</div>
							</div>
						</form>
					</div>
					<div class="col-sm-12">
					</div>
				</div>
			</form>
		<?php
			if(isset($_POST['payroll_approve'])){
				$count = 0;
				$username = $_POST['sess_id'];
				$sql = "SELECT * FROM temp_table_id WHERE org_id = ?";
				include '../include/conn.php';
				$to_print = mysqli_prepare($conn,$sql);
				if(!$to_print){
					echo "";
				}else{
					mysqli_stmt_bind_param($to_print,'s',$username);
					mysqli_stmt_execute($to_print);
					$result = mysqli_stmt_get_result($to_print);
					while($row = mysqli_fetch_assoc($result)){
						$username = $row['org_id'];
						$employee_id = $row['employee_id'];
						$_SESSION['org_id'] = $username;
						$user_id = $_SESSION['org_id'];
						//$employee = $row['employee_id'];
						//$_SESSION['employee_id'] = $employee_id;
						header('Location: fpdf186/run_payroll.php');
					}
				}
			}
		//Summary list of payroll in .pdf	
			if(isset($_POST['payroll_summary'])){
				$org_id = $_POST['sess_id'];
				$_SESSION['organisation_id'] = $org_id;
				header('Location: fpdf186/summary.php');
			}
		//Payslip Collation
			if(isset($_POST['payroll_collate'])){
				$org_id = $_POST['sess_id'];
				$_SESSION['organisation_id'] = $org_id;
				header('Location: fpdf186/payslip_collate.php');
			}
		?>

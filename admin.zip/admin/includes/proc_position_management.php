<h3>Position Management</h3>
	<div class="row gens">
		<div class="col-sm-12">
			<div class="row">
				<div class="col-sm-3 form-group">
					<form action="" method="POST">
						<button class="form-control approve" name="position_add" type="submit">Add Position</button>
					</form>
				</div>
				<div class="col-sm-3 form-group">
					<form action="" method="POST">
						<button class="form-control approve" name="position_edit" type="submit">Edit Position</button>
					</form>
				</div>
				<div class="col-sm-3 form-group">
					<form action="" method="POST">
						<button class="form-control approve" name="position_del" type="submit">Delete Position</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php
		include "action/proc_position_management.php";
	?>

<h3>Employee Management</h3>
<br>
<div class="row gens">
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button class="approve form-control" name="add_employee">Add Employee</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button class="approve form-control" name="del_employee">Delete Employee</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button class="approve form-control" name="edit_employee">Edit Employee</button>
		</form>
	</div>
</div>
<?php
	/*include "../include/conn.php";
	$sql = "SELECT * FROM users WHERE email = ?";
	$search = mysqli_prepare($conn,$sql);
	if(!$search){
		echo mysqli_error($conn);
	}else{
		
	}
?>
<h1 class="text-center">Change password after first login!</h1>
<br>
<p class="text-center"><?php //echo $_SESSION['error'];?></p>
<br>
<style>
    form {
        width: 100%;
        max-width: 400px;
        margin: auto;
    }
</style>
<form action="" method="POST">
    <div class="row">
        <div class="col-sm-12 form-group">
            <input type="password" class="form-control input-lg" name="old_password" placeholder="Old Password..." required>
        </div>
        <div class="col-sm-12 form-group">
            <input type="password" class="form-control input-lg" name="new_password" placeholder="New Password..." required>
        </div>
        <div class="col-sm-12 form-group">
            <input type="password" class="form-control input-lg" name="confirm_password" placeholder="Confirm Password..." required>
        </div>
		<div class="col-sm-12 form-group">
			<select name="security_question" class="form-control input-lg">
				<option value="City">What is your city of birth?</option>
				<option value="Pet">What is the name of your first pet?</option>
				<option value="Name">What is your mothers maiden name?</option>
				<option value="Crush">What was the name of your high school crush?</option>
				<option value="Hero">Who was your childhood hero?</option>
			</select>
		</div>
		<div class="col-sm-12 form-group">
			<input type="text" class="form-control input-lg" name="security_answer" placeholder="Answer..." required>
		</div>
        <div class="col-sm-6 form-group">
            <input type="submit" class="form-control approve" name="submit_new_password" value="Change Password">
        </div>
    </div>
</form>
<?php

    include "../include/conn.php";
	
    if(isset($_POST['submit_new_password'])){
        // Sanitize and validate form data
        $old_pass = trim($_POST['old_password']);
		$old_password = md5($old_pass);
        $new_password = trim($_POST['new_password']);
        $confirm_password = trim($_POST['confirm_password']);
		$security_question = trim($_POST['security_question']);
		$security_answer = trim($_POST['security_answer']);

        // Check if all fields are filled
        if(empty($old_password) || empty($new_password) || empty($confirm_password) || empty($security_question) || empty($security_answer)){
            echo $_SESSION['error'] = "All fields are required.";
            header('Location: password_change.php');
            exit();
        }

        // Validate password format
        $password_length = strlen($new_password);
        if($password_length < 8 || $password_length > 20){
            echo $_SESSION['error'] = "Password must be between 8 and 20 characters long.";
            header('Location: password_change.php');
            exit();
        }

        $special_characters = preg_match_all("/[!@#$%^&*()\-_=+{};:,<.>]/", $new_password);
        if($special_characters < 3){
            echo $_SESSION['error'] = "Password must include at least 3 special characters.";
            header('Location: password_change.php');
            exit();
        }

        // Check if new password matches the confirm password
        if($new_password !== $confirm_password){
            echo $_SESSION['error'] = "New password and confirm password do not match.";
            header('Location: password_change.php');
            exit();
        }

        // Check if old password matches the current password in the database
        $email = $_SESSION['username']; // Assuming email is stored in session after login
        $sql = "SELECT password FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn,$sql);
        mysqli_stmt_bind_param($stmt,'s', $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
		
        if(!$row || $old_password !== $row['password']){
            echo $_SESSION['error'] = "Incorrect old password.";
            header('Location: password_change.php');
            exit();
        }

        // Hash the new password
        $hashed_password = md5($new_password);

        // Update the password in the database
        $update_sql = "UPDATE users SET password = ?, password_changed = 2, security_question = ?, security_answer = ? WHERE email = ?";
        $update_stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($update_stmt,'ssss',$hashed_password,$email,$security_question,$security_answer);
        
        if(mysqli_stmt_execute($update_stmt)){
            echo $_SESSION['success'] = "Password changed successfully.";
            header('Location: dashboard.php'); // Redirect to dashboard or any other page
            exit();
        }else{
            echo $_SESSION['error'] = "Failed to change password. Please try again later.";
            header('Location: password_change.php');
            exit();
        }
    }*/
?>
<?php
	include '../assets/header.php';	
	
	if(isset($_POST['submit_new_password'])){
		include "../include/conn.php";

		// Sanitize and validate form data
		$old_pass = trim($_POST['old_password']);
		$old_password = md5($old_pass);
		$new_password = trim($_POST['new_password']);
		$confirm_password = trim($_POST['confirm_password']);
		$security_question = trim($_POST['security_question']);
		$security_answer = trim($_POST['security_answer']);

		// Check if all fields are filled
		if(empty($old_password) || empty($new_password) || empty($confirm_password) || empty($security_question) || empty($security_answer)){
			$_SESSION['error'] = "All fields are required.";
			header('Location: password_change.php');
			exit();
		}

		// Validate password format
		$password_length = strlen($new_password);
		if($password_length < 8 || $password_length > 20){
			$_SESSION['error'] = "Password must be between 8 and 20 characters long.";
			header('Location: password_change.php');
			exit();
		}

		$special_characters = preg_match_all("/[!@#$%^&*()\-_=+{};:,<.>]/", $new_password);
		if($special_characters < 3){
			$_SESSION['error'] = "Password must include at least 3 special characters.";
			header('Location: password_change.php');
			exit();
		}

		// Check if new password matches the confirm password
		if($new_password !== $confirm_password){
			$_SESSION['error'] = "New password and confirm password do not match.";
			header('Location: password_change.php');
			exit();
		}

		// Check if old password matches the current password in the database
		$email = $_SESSION['username']; // Assuming email is stored in session after login
		$sql = "SELECT password FROM users WHERE email = ?";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, 's', $email);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$row = mysqli_fetch_assoc($result);
		
		if(!$row || $old_password !== $row['password']){
			$_SESSION['error'] = "Incorrect old password.";
			header('Location: password_change.php');
			exit();
		}

		// Hash the new password
		$hashed_password = md5($new_password);

		// Update the password in the database
		$update_sql = "UPDATE users SET password = ?, password_changed = 2, security_question = ?, security_answer = ? WHERE email = ?";
		$update_stmt = mysqli_prepare($conn, $update_sql);
		mysqli_stmt_bind_param($update_stmt, 'ssss', $hashed_password, $security_question, $security_answer, $email);
		
		if(mysqli_stmt_execute($update_stmt)){
			$_SESSION['success'] = "Password changed successfully.";
			header('Location: dashboard.php'); // Redirect to dashboard or any other page
			exit();
		}else{
			$_SESSION['error'] = "Failed to change password. Please try again later.";
			header('Location: password_change.php');
			exit();
		}
	}
?>

<h1 class="text-center">Change password after first login!</h1>
<br>
<p class="text-center"><?php if(isset($_SESSION['error'])) echo $_SESSION['error']; ?></p>
<br>
<style>
    form {
        width: 100%;
        max-width: 400px;
        margin: auto;
    }
</style>
<form action="" method="POST">
    <div class="row">
        <div class="col-sm-12 form-group">
            <input type="password" class="form-control input-lg" name="old_password" placeholder="Old Password..." required>
        </div>
        <div class="col-sm-12 form-group">
            <input type="password" class="form-control input-lg" name="new_password" placeholder="New Password..." required>
        </div>
        <div class="col-sm-12 form-group">
            <input type="password" class="form-control input-lg" name="confirm_password" placeholder="Confirm Password..." required>
        </div>
        <div class="col-sm-12 form-group">
            <select name="security_question" class="form-control input-lg" required>
                <option value="City">What is your city of birth?</option>
                <option value="Pet">What is the name of your first pet?</option>
                <option value="Name">What is your mother's maiden name?</option>
                <option value="Crush">What was the name of your high school crush?</option>
                <option value="Hero">Who was your childhood hero?</option>
            </select>
        </div>
        <div class="col-sm-12 form-group">
            <input type="text" class="form-control input-lg" name="security_answer" placeholder="Answer..." required>
        </div>
        <div class="col-sm-6 form-group">
            <input type="submit" class="form-control approve" name="submit_new_password" value="Change Password">
        </div>
    </div>
</form>

<?php
	session_start();
?>
<h1 class="text-center">FORGOT PASSWORD?</h1>
<h2 class="text-center">Reset it Easy!</h2>
<?php
	session_start();

	if(isset($_POST['verify_answer'])){
		// Sanitize user inputs
		$security_tpin = isset($_POST['security_tpin']) ? mysqli_real_escape_string($conn, $_POST['security_tpin']) : '';
		$security_email = isset($_POST['security_email']) ? mysqli_real_escape_string($conn, $_POST['security_email']) : '';
		$security_question = isset($_POST['security_question']) ? mysqli_real_escape_string($conn, $_POST['security_question']) : '';
		$security_answer = isset($_POST['security_answer']) ? mysqli_real_escape_string($conn, $_POST['security_answer']) : '';

		include "../include/conn.php";

		$sql = "SELECT org_email FROM org_supa_register WHERE tpin = ?";
		$read = mysqli_prepare($conn, $sql);
		if(!$read){
			exit("Database error");
		}else{
			mysqli_stmt_bind_param($read, 's', $security_tpin);
			mysqli_stmt_execute($read);
			$result = mysqli_stmt_get_result($read);
			$row = mysqli_fetch_assoc($result);
			$r_email = $row['org_email'];

			if($r_email === $security_email){
				$sql = "SELECT * FROM users WHERE email = ?";
				$read = mysqli_prepare($conn, $sql);
				if(!$read){
					exit("Database error");
				}else{
					mysqli_stmt_bind_param($read, 's', $r_email);
					mysqli_stmt_execute($read);
					$result = mysqli_stmt_get_result($read);
					$row = mysqli_fetch_assoc($result);
					$r_question = $row['security_question'];
					$r_answer = $row['security_answer'];

					if($r_question === $security_question && $r_answer === $security_answer){
						$_SESSION['email_reset'] = $r_email;
						header('Location: reset_password.php');
						exit();
					}else{
						$_SESSION['error'] = "Verification Error!";
						header('Location: forgot_password.php');
						exit();
					}
				}
			}else{
				$_SESSION['error'] = 'Email Error!';
				header('Location: forgot_password.php');
				exit();
			}
		}
	}

	// Display error message if any
	echo isset($_SESSION['error']) ? $_SESSION['error'] : '';
?>


<div class="container-fluid">
	<div class="container">
		<style>
			form {
				width: 100%;
				max-width: 500px;
				margin: auto;
			}
		</style>
		<form action="" method="POST">
			<div class="row">
				<div class="col-sm-12 form-group">
					<input type="email" class="form-control input-lg" name="security_email" placeholder="User Email Address..." required>
				</div>
				<div class="col-sm-12 form-group">
					<input type="text" class="form-control input-lg" name="security_tpin" placeholder="TPIN..." required>
				</div>
				<div class="col-sm-12 form-group">
					<select name="security_question" class="form-control input-lg">
						<option value="City">What is your city of birth?</option>
						<option value="Pet">What is the name of your first pet?</option>
						<option value="Name">What is your mother's maiden name?</option>
						<option value="Crush">What was the name of your high school crush?</option>
						<option value="Hero">Who was your childhood hero?</option>
					</select>
				</div>
				<div class="col-sm-12 form-group">
					<input type="text" class="form-control input-lg" name="security_answer" placeholder="Answer..." required>
				</div>
				<div class="col-sm-6 form-group">
					<input type="submit" class="form-control approve" name="verify_answer" value="Check">
				</div>
			</div>
		</form>
	</div>
</div>

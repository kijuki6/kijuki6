<h3>Charge Management</h3>
<div class="row gens">
		<div class="col-sm-12">
			<div class="row">
				<div class="col-sm-3 form-group">
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="charge_add" type="submit"><i class="fa fa-plus" aria-hidden="true"> Add Charge</button>
					</form>
				</div>
				<div class="col-sm-3 form-group">
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="charge_edit" type="submit">Edit Charge</button>
					</form>
				</div>
				<div class="col-sm-3 form-group">
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="charge_del" type="submit">Delete Charge</button>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php
	include 'action/proc_charge_management.php';
?>
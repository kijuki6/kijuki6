<div class="col-sm-12">
	<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Add Employee to Organisation Payroll"><i>Add Employee</i></h4>
	<br>
</div>
	<div class="col-sm-12">
		<form action="" method="POST">
			<div class="row">
				<div class="col-sm-3 form-group">
					<label>First Name</label>
					<input type="text" name="add_fname" class="form-control" placeholder="Employee First Name..." required>
				</div>
				<div class="col-sm-3 form-group">
					<label>Last Name</label>
					<input type="text" name="add_lname" class="form-control" placeholder="Employee Last Name..." required>
				</div>
				<div class="col-sm-3 form-group">
					<label>Other Name</label>
					<input type="text" name="add_oname" class="form-control" placeholder="Employee Other Name...">
				</div>
				<div class="col-sm-3 form-group">
					<label>NRC/Employee ID</label>
					<input type="text" name="add_id" class="form-control" placeholder="Employee ID..." required>
				</div>
				<div class="col-sm-3 form-group">
					<label>Phone #</label>
					<input type="text" name="add_phone" class="form-control" placeholder="Employee Phone..." required>
				</div>
				<div class="col-sm-3 form-group">
					<label>Date of Birth</label>
					<input type="date" name="add_dob" class="form-control" required>
				</div>
				<div class="col-sm-3 form-group">
					<label>Email Address</label>
					<input type="text" name="add_email" class="form-control" placeholder="Employee Email..." required>
				</div>
				<div class="col-sm-3 form-group">
					<label>Home Address</label>
					<input type="text" name="add_address" class="form-control" placeholder="Employee Address..." required>
				</div>
				<div class="col-sm-3 form-group">
					<input type="submit" name="add_employee_submit" class="form-control approve" value="Add Employee">
				</div>
			</div>
		</form>
	</div>
<?php
	include 'action/proc_add_employee.php';
?>


		<div class="col-sm-12">
			<div class="row">
				<div class="col-sm-3 form-group">
					<a href="dashboard.php"><button class="form-control approve">&#60;&#60;&#60; Back</button></a>
				</div>
				<div class="col-sm-3 form-group">
					<form action="" method="POST">
						<button class="form-control approve" name="payroll_review_employee_list" type="submit">Payroll Review(Employee List)</button>
					</form>
				</div>
				
				<div class="col-sm-3 form-group">
					<a href="payroll_history.php"><button class="form-control approve" name="payroll_history" type="submit">Payroll History</button></a>
				</div>
			</div>
		</div>
	
<?php
	include 'action/proc_payroll_management.php';
?>

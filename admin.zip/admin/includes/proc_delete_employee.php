<div class="col-sm-12">
	<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;" title="Delete Employee From Organisation Payroll"><i>Delete Employee</i></h4>
	<br>
</div>
	<div class="col-sm-12">
		<form action="" method="POST">
			<div class="row">
				<div class="col-sm-6 form-group">
					<select class="form-control" name="employee_id">
						<option value="">-- Select Employee from List --</option>
						<?php
							include '../include/conn.php';
							
							$sql = "SELECT * FROM org_emp_management WHERE org_id = ?";
							$readStatement = mysqli_prepare($conn,$sql);
							if(!$readStatement){
								echo "Cannot read values at the moment!";
							}else{
								mysqli_stmt_bind_param($readStatement,'s',$username);
								mysqli_stmt_execute($readStatement);
								$result = mysqli_stmt_get_result($readStatement);
								$count = 0;
								while($row = mysqli_fetch_assoc($result)){
									$count = $count + 1;
									$employee_fname = $row['fname'];
									$employee_lname = $row['lname'];
									$employee_oname = $row['oname'];
									$employee_id = $row['employee_id'];
								?>
									<option value="<?php echo $employee_id?>"><?php echo $count.". ".$employee_lname." ".$employee_fname." ".$employee_oname;?></option>
								<?php
								}
							}
						?>
					</select>
				</div>
				<div class="col-sm-3 form-group">
					<input type="submit" name="delete_employee" value="Delete Employee" class="form-control approve">
				</div>
			</div>
		</form>
	</div>

<?php
	include 'action/proc_delete_employee.php';
?>
<h3>General Settings</h3>
<br>
<div class="row gens">
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="emp_management" class="approve form-control">Employee Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="tax_management" class="approve form-control">Tax Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="stat_mngt" class="approve form-control">Statutory Deduction Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="allowance_mngt" class="approve form-control">Allowance Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="dpt_management" class="approve form-control">Department Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="chrg_management" class="approve form-control">Charge Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="ded_management" class="approve form-control">Deduction Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="slry_management" class="approve form-control">Salary Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="pos_management" class="approve form-control">Position Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="rol_management" class="approve form-control">Role Management</button>
		</form>
	</div>
	<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="tad_management" class="approve form-control">Time/Attendance Management</button>
		</form>
	</div>
	<!--<div class="col-sm-3 form-group">
		<form action="" method="POST">
			<button type="submit" name="payroll_management" class="approve form-control">Payroll Management</button>
		</form>
	</div>-->
	<div class="col-sm-3 form-group">
		<a href="payroll_management.php"><button class="approve form-control">Payroll Management</button></a>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<?php
			include "../include/conn.php";
		?>
	</div>
</div>
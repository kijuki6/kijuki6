<?php
	//Set session to continue with password reset
	$reset_email = $_SESSION['email_reset'];
?>
<h1 class="text-center">RESET PASSWORD?</h1>
<h2 class="text-center">Reset it Easy!</h2>
<?php
	//Reset password and replace with new password in database
	if(isset($_POST['reset_password'])){
		$security_email = $_POST['security_email'];
		$new_password = $_POST['new_password'];
		$confirm_password = $_POST['confirm_password'];
		
		$hash_password = md5($new_password);
		
		if($new_password === $confirm_password){
			include "../include/conn.php";
			$sql = "UPDATE users SET password = ? WHERE email = ?";
			$updateStatement = mysqli_prepare($conn,$sql);
			if(!$updateStatement){
				echo "";
			}else{
				mysqli_stmt_bind_param($updateStatement,'ss',$hash_password,$security_email);
				mysqli_stmt_execute($updateStatement);
				echo "<h4 class='text-center' style='color: #50c878;'>***Password successfully changed***</h4><p class='text-center'><a href='logout.php'><button>Exit</button></a></p>";
				mysqli_close($conn);
			}
		}
	}
	if(isset($_POST['reset_password'])){
		//nothing
	}else{
?>
		<div class="container-fluid">
			<div class="container">
				<style>
					form {
						width: 100%;
						max-width: 500px;
						margin: auto;
					}
				</style>
				<form action="" method="POST">
					<div class="row">
						<div class="col-sm-12 form-group">
							<input type="hidden" class="form-control input-lg" name="security_email" value="<?php echo $reset_email;?>">
						</div>
						<div class="col-sm-12 form-group">
							<input type="password" class="form-control input-lg" name="new_password" placeholder="Password..." required>
						</div>
						<div class="col-sm-12 form-group">
							<input type="password" class="form-control input-lg" name="confirm_password" placeholder="Confirm Password..." required>
						</div>
						<div class="col-sm-6 form-group">
							<input type="submit" class="form-control approve" name="reset_password" value="Reset Paasword">
						</div>
					</div>
				</form>
			</div>
		</div>
<?php
	}
?>
<?php
	ob_start();
	session_start();
	$username = $_SESSION['username'];
	$organisation_name = $_SESSION['organisation_name'];
	$organisation_email = $_SESSION['organisation_email'];
	$org_tpin = $_SESSION['tpin'];
	if(!isset($_SESSION['username'])){
		header('Location: ../login.php');
	}else{
		include "../assets/header.php";
		include "../assets/body.php";
		include "../include/conn.php";
		include "includes/proc_dash.php";
		include "../assets/footer.php";
	}
?>
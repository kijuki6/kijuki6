<?php
	ob_start();
	session_start();
	$username = $_SESSION['username'];
	$organisation_name = $_SESSION['organisation_name'];
	$organisation_email = $_SESSION['organisation_email'];
	if(!isset($_SESSION['username'])){
		header('Location: ../login.php');
	}else{
		include "../assets/header.php";
		include "../assets/body.php";
		include "../include/conn.php";
		include "includes/password_change.php";
		include "../assets/footer.php";
	}
?>
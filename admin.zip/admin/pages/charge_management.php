<div class="container-fluid">
	<div class="row">
		<div class="row">
			<div class="col-sm-10 topbar">
				<h1>Green Pine Payroll System | [Org Name]</h1>
			</div>
			<div class="col-sm-2 topbar topbar-button"><a href="../logout.php"><button class="logout-button">Logout</button></a></div>
			<div class="col-sm-12">
				<hr class="separator">
			</div>
		</div>
		<div class="col-sm-3 sidebar">
			<a href="dashboard.php"><button class="side-button"><i class="fa fa-home" aria-hidden="true"></i> Dashboard</button></a>
			<a href="employee_management.php"><button class="side-button"><i class="fa fa-users" aria-hidden="true"></i> Employee Management</button></a>
			<a href="allowance_management.php"><button class="side-button"><i class="fa fa-database" aria-hidden="true"></i> Allowance Management</button></a>
			<a href="department_management.php"><button class="side-button"><i class="fa fa-list-ol" aria-hidden="true"></i> Department Management</button></a>
			<a href="position_management.php"><button class="side-button"><i class="fa fa-arrows-v" aria-hidden="true"></i> Position Management</button></a>
			<a href="salary_management.php"><button class="side-button"><i class="fa fa-gbp" aria-hidden="true"></i> Salary Management</button></a>
			<a href="charge_management.php"><button class="side-button active"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Management</button></a>
			<a href="charge_sheet.php"><button class="side-button"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Sheet</button></a>
			<a href="time_attendance_management.php"><button class="side-button"><i class="fa fa-clock-o" aria-hidden="true"></i> Time &amp; Attendance Management</button></a>
			<a href="time_sheet.php"><button class="side-button"><i class="fa fa-sticky-note-o" aria-hidden="true"></i> Time Sheet</button></a>
			<a href="payroll_management.php"><button class="side-button"><i class="fa fa-usd" aria-hidden="true"></i> Payroll Management</button></a>
		</div>
		<div class="col-sm-9 dashboardf">
			<h4 style="font-size: 3em; padding: 10px;">Charge Management</h4>
			<div style="padding: 5px;"><p class="small" title="Add, Edit and Delete employee charges from here."><i>*** Add, Edit and Delete Employee Charges from here.***</i></p></div>		
				<div class="col-sm-3 form-group" style="background-color: #1e293b; height: 80px;">	
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="charge_add" type="submit"><i class="fa fa-plus" aria-hidden="true"></i> Add Charge</button>
					</form>
				</div>
				<div class="col-sm-3 form-group" style="background-color: #1e293b; height: 80px;">	
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="charge_edit" type="submit"><i class="fa fa-minus" aria-hidden="true"></i> Edit Charge</button>
					</form>
				</div>
				<div class="col-sm-3 form-group" style="background-color: #1e293b; height: 80px;">	
					<br>
					<form action="" method="POST">
						<button class="form-control approve" name="charge_del" type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Delete Charge</button>
					</form>
				</div>
			<div class="row" style="padding: 5px;">
				<div class="col-sm-12">
					<?php
						include 'action/proc_charge_management.php';
					?>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container-fluid">
	<div class="row">
		<div class="row">
			<div class="col-sm-10 topbar">
				<h1>Green Pine Payroll System | [Org Name]</h1>
			</div>
			<div class="col-sm-2 topbar topbar-button"><a href="../logout.php"><button class="logout-button">Logout</button></a></div>
			<div class="col-sm-12">
				<hr class="separator">
			</div>
		</div>
		<div class="col-sm-3 sidebar">
			<a href="dashboard.php"><button class="side-button"><i class="fa fa-home" aria-hidden="true"></i> Dashboard</button></a>
			<a href="employee_management.php"><button class="side-button"><i class="fa fa-users" aria-hidden="true"></i> Employee Management</button></a>
			<a href="allowance_management.php"><button class="side-button"><i class="fa fa-database" aria-hidden="true"></i> Allowance Management</button></a>
			<a href="department_management.php"><button class="side-button"><i class="fa fa-list-ol" aria-hidden="true"></i> Department Management</button></a>
			<a href="position_management.php"><button class="side-button"><i class="fa fa-arrows-v" aria-hidden="true"></i> Position Management</button></a>
			<a href="salary_management.php"><button class="side-button"><i class="fa fa-gbp" aria-hidden="true"></i> Salary Management</button></a>
			<a href="charge_management.php"><button class="side-button"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Management</button></a>
			<a href="charge_sheet.php"><button class="side-button"><i class="fa fa-outdent" aria-hidden="true"></i> Charge Sheet</button></a>
			<a href="time_attendance_management.php"><button class="side-button active"><i class="fa fa-clock-o" aria-hidden="true"></i> Time &amp; Attendance Management</button></a>
			<a href="time_sheet.php"><button class="side-button"><i class="fa fa-sticky-note-o" aria-hidden="true"></i> Time Sheet</button></a>
			<a href="payroll_management.php"><button class="side-button"><i class="fa fa-usd" aria-hidden="true"></i> Payroll Management</button></a>
		</div>
		<div class="col-sm-9 dashboardf">
			<h4 style="font-size: 3em; padding: 10px;">Time &amp; Attendance Managemement</h4>
			<div style="padding: 5px;"><p class="small" title="Add and Edit Time and Attendance parameters from here."><i>*** Add and Edit Time &amp; Attendance parameters from here.***</i></p></div>						
			<div class="col-sm-3 form-group" style="background-color: #1e293b; height: 80px;">	
				<br>
				<form action="" method="POST">
					<button class="form-control approve" name="time_add" type="submit"><i class="fa fa-plus" aria-hidden="true"></i> Add Time</button>
				</form>
			</div>
			<div class="row" style="padding: 5px;">
				<div class="col-sm-12">
					<?php
						include 'action/proc_time_attendance_management.php';
					?>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<style>
						table {
							width: 100%;
						}
					</style>
					<br>
					<div class="" style="border: 1px solid #000; margin: 10px; padding: 10px;">
						<h4 style="font-size: 2em; padding: 10px; color: #b3b3b3;"><i>CURRENT TIME/ATTENDANCE SETTINGS</i></h4>
						<table>
							<thead>
								<tr>
									<th>Min Clock-In Time</th>
									<th>Max Clock-Out Time</th>
									<th>Lunch Duration</th>
									<th>Max Work Hours</th>
									<th>Date/Time Modified</th>
								</tr>
							</thead>
							<tbody>
								<tr>
								<?php
									include '../include/conn.php';
									$sql = "SELECT * FROM org_time_attendance WHERE org_id = ?";
									$read = mysqli_prepare($conn,$sql);
									if(!$read){
										echo "";
									}else{
										mysqli_stmt_bind_param($read,'s',$username);
										mysqli_stmt_execute($read);
										$result = mysqli_stmt_get_result($read);
										$row = mysqli_fetch_assoc($result);
										@$clock_in = $row['clock_in'];
										@$clock_out = $row['clock_out'];
										@$lunch = $row['lunch'];
										@$max_hours = $row['max_hours'];
										@$date_time_modified = $row['date_added'];
										$empty = "<p style='color: #c7c7c7;'><i>No data availabe</i></p>";
								?>
										<td><?php if(empty($clock_in)){
											echo $empty;
										}else{
											echo $clock_in;
										}?></td>
										<td><?php if(empty($clock_out)){
											echo $empty;
										}else{
											echo $clock_out;
										}?></td>
										<td><?php if(empty($lunch)){
											echo $empty;
										}else{
											echo $lunch;
										}?></td>
										<td><?php if(empty($max_hours)){
											echo $empty;
										}else{
											echo $max_hours;
										}?></td>
										<td><?php if(empty($date_time_modified)){
											echo $empty;
										}else{
											echo $date_time_modified;
										}?></td>
								<?php
									}
								?>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>